const processed   = new Set();
const processing  = new Set();
const _barByContainer = new WeakMap(); // container → bar element (bar may live outside container)
let hideTimer    = null;
let pinnedSpan   = null;

// ─── Settings ─────────────────────────────────────────────────────────────────

const PRESET_CONFIGS = {
  essential: {
    signals:     { citation: true, medical: true, legal: true, qty: false, superlative: false, temporal: false, math: false, hedge: false, negated: false, model: false },
    minTier:     "low",
    verification: true,
  },
  standard: {
    signals:     { citation: true, medical: true, legal: true, qty: true, superlative: true, temporal: true, math: true, hedge: true, negated: true, model: true },
    minTier:     "medium",
    verification: true,
  },
  thorough: {
    signals:     { citation: true, medical: true, legal: true, qty: true, superlative: true, temporal: true, math: true, hedge: true, negated: true, model: true },
    minTier:     "info",
    verification: true,
  },
};

const DEFAULT_SETTINGS = {
  preset:       "standard",
  signals:      { ...PRESET_CONFIGS.standard.signals },
  minTier:      "medium",
  verification: true,
  defaultView:  "simple",
  showCleanBar:      true,
  showMultipliers:   true,
};

let settings = { ...DEFAULT_SETTINGS, signals: { ...DEFAULT_SETTINGS.signals } };
let resolvedCache = {}; // { [sentenceKey]: string[] } — persisted in chrome.storage.local

function sentenceKey(text) { return (text || "").trim().slice(0, 120); }

chrome.storage.local.get(["clSettings", "clResolved"], (data) => {
  if (data.clSettings) {
    settings = { ...DEFAULT_SETTINGS, ...data.clSettings, signals: { ...DEFAULT_SETTINGS.signals, ...(data.clSettings.signals ?? {}) } };
    activeView = settings.defaultView;
    applySettingsToDOM();
  }
  if (data.clResolved) resolvedCache = data.clResolved;
});

// Keep cache in sync when another tab resolves a signal
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.clResolved) {
    resolvedCache = changes.clResolved.newValue ?? {};
  }
});

function saveSettings() {
  chrome.storage.local.set({ clSettings: settings });
}

// Detect if current signal/minTier state matches a preset
function detectPreset() {
  for (const [name, cfg] of Object.entries(PRESET_CONFIGS)) {
    if (cfg.minTier !== settings.minTier) continue;
    if (Object.keys(cfg.signals).every(k => cfg.signals[k] === settings.signals[k])) return name;
  }
  return null;
}

// Strip all existing highlights from the DOM and re-run analysis from scratch.
// Called whenever settings change so the new thresholds / signal toggles take effect.
function applySettingsToDOM() {
  dismissTooltip();

  // Unwrap all flagged spans back to plain text
  document.querySelectorAll("[data-certainty]").forEach(span => {
    if (!span.isConnected) return;
    span.replaceWith(document.createTextNode(span.textContent));
  });

  // Remove response bars so they get re-inserted with the correct count
  document.querySelectorAll(".cl-response-bar").forEach(bar => bar.remove());

  // Clear processed set so analyzeElement runs fresh on every container
  processed.clear();

  // Re-run analysis on all visible response containers
  scanForContainers(document.body);

  // Apply clean bar visibility preference after a tick (bars inserted async)
  setTimeout(() => {
    document.querySelectorAll(".cl-response-bar").forEach(bar => {
      if (bar.querySelector(".cl-response-bar-clean")) {
        bar.style.display = settings.showCleanBar ? "" : "none";
      }
    });
  }, 100);
}

// Remove highlights from spans that no longer have any enabled signals after a settings change.
// Does not re-scan or re-analyze — only cleans up stale spans already in the DOM.
function pruneStaleSpans() {
  document.querySelectorAll("[data-certainty]").forEach(span => {
    if (!span.isConnected) return;
    const scores = {
      hedge:       Number(span.dataset.scoreHedge       ?? 0),
      claim:       Number(span.dataset.scoreClaim       ?? 0),
      temporal:    Number(span.dataset.scoreTemporal    ?? 0),
      citation:    Number(span.dataset.scoreCitation    ?? 0),
      medical:     Number(span.dataset.scoreMedical     ?? 0),
      legal:       Number(span.dataset.scoreLegal       ?? 0),
      math:        Number(span.dataset.scoreMath        ?? 0),
      superlative: Number(span.dataset.scoreSuperlative ?? 0),
      qty:         Number(span.dataset.scoreQty         ?? 0),
      negated:     Number(span.dataset.scoreNegated     ?? 0),
      model:       Number(span.dataset.scoreModel       ?? 0),
    };
    const enabledSignalFired = Object.keys(settings.signals).some(
      k => settings.signals[k] && (scores[k] ?? 0) > 0
    );
    if (!enabledSignalFired || !tierMeetsMin(span.dataset.certainty)) {
      span.classList.remove("cl-uncertain-high", "cl-uncertain-medium", "cl-uncertain-info");
      span.removeAttribute("data-certainty");
    }
  });
}

// Re-render the open tooltip in place after a settings change.
// If the updated settings scope out all signals, remove the highlight and let
// the tooltip close naturally on the next outside click. Never triggers a full re-scan.
function refreshOpenTooltip() {
  if (!lastTooltipData || !lastTooltipEvent) return;

  // Determine which signals remain after applying updated settings + resolved cache
  const { scores, sentenceText, contentType = "natural" } = lastTooltipData;
  const isCode = contentType === "code";
  const allCriteria = isCode ? CODE_CRITERIA : PROSE_CRITERIA;
  const criteria = isCode ? allCriteria : allCriteria.filter(c => settings.signals[c.key] !== false);
  const sKey = sentenceKey(sentenceText);
  const preResolved = new Set(resolvedCache[sKey] ?? []);

  const remainingSignals = criteria.filter(c => {
    if (preResolved.has(c.key)) return false;
    const score = scores?.[c.key] ?? 0;
    return score > 0;
  });

  // Check if the recomputed certainty still meets the minTier threshold
  const TIER_ORDER = { high: 0, info: 1, medium: 2, low: 3 };
  const recomputed = recomputeAfterResolve(scores ?? {}, preResolved);
  const newCertainty = combinedToCertainty(recomputed);
  const meetsThreshold = TIER_ORDER[newCertainty] >= TIER_ORDER[settings.minTier];

  if (remainingSignals.length === 0 || !meetsThreshold) {
    // All signals scoped out — remove highlight and let popup fade on outside click
    const _span = lastTooltipData._span;
    if (_span && _span.isConnected) {
      _span.classList.remove("cl-uncertain-high", "cl-uncertain-medium", "cl-uncertain-info");
      _span.removeAttribute("data-certainty");
    }
    dismissTooltip();
    lastTooltipData = null;
    return;
  }

  // Re-render tooltip with updated settings
  showTooltip(lastTooltipEvent, lastTooltipData);
}

// ─── Working prompt buffer ────────────────────────────────────────────────────
// Tracks the evolving prompt across chained rewrites within one conversation turn.
// Reset automatically when the user sends a new message.

let promptHistory = []; // [{text, mode}] — grows with each applied rewrite
let activeView    = "simple"; // persists across spans

function resetWorkingPrompt() {
  promptHistory = [];
}

function currentWorkingPrompt() {
  return promptHistory.length ? promptHistory[promptHistory.length - 1].text : null;
}

// ─── Word diff ────────────────────────────────────────────────────────────────

function wordDiff(a, b) {
  const tok = s => s.match(/\S+|\s+/g) || [];
  const aw = tok(a), bw = tok(b);
  const m = aw.length, n = bw.length;
  const dp = Array.from({length: m + 1}, () => new Array(n + 1).fill(0));
  for (let i = 1; i <= m; i++)
    for (let j = 1; j <= n; j++)
      dp[i][j] = aw[i-1] === bw[j-1] ? dp[i-1][j-1] + 1 : Math.max(dp[i-1][j], dp[i][j-1]);
  const ops = [];
  let i = m, j = n;
  while (i > 0 || j > 0) {
    if (i > 0 && j > 0 && aw[i-1] === bw[j-1]) {
      ops.unshift({t: aw[i-1], k: "s"}); i--; j--;
    } else if (j > 0 && (i === 0 || dp[i][j-1] >= dp[i-1][j])) {
      ops.unshift({t: bw[j-1], k: "a"}); j--;
    } else {
      ops.unshift({t: aw[i-1], k: "r"}); i--;
    }
  }
  return ops;
}

function renderDiff(ops) {
  return ops.map(({t, k}) => {
    const e = escapeHtml(t);
    return k === "a" ? `<ins class="cl-diff-add">${e}</ins>`
         : k === "r" ? `<del class="cl-diff-del">${e}</del>`
         : e;
  }).join("");
}

function modeLabel(mode) {
  return mode === "integrate" ? "Quick tweak" : "Full rewrite";
}

const CIRCLE_NUMS = ["①","②","③","④","⑤","⑥","⑦","⑧","⑨","⑩"];
function circleNum(n) { return CIRCLE_NUMS[n - 1] || `#${n}`; }

// ─── History timeline ─────────────────────────────────────────────────────────

function buildHistoryHtml(originalPrompt) {
  if (!promptHistory.length) return "";
  const items = [
    { text: originalPrompt, label: "Original", isCurrent: false },
    ...promptHistory.map((h, i) => ({
      text: h.text,
      label: modeLabel(h.mode),
      isCurrent: i === promptHistory.length - 1,
    })),
  ];
  return `<div class="cl-prompt-history">` +
    items.map((item, idx) => {
      const truncated = item.text.length > 75
        ? item.text.slice(0, 75) + "\u2026"
        : item.text;
      const action = item.isCurrent
        ? `<button class="cl-ph-reset" title="Reset to original">\u2715</button>`
        : `<button class="cl-ph-use" data-prompt="${escapeAttr(item.text)}">use</button>`;
      return `
        ${idx > 0 ? `<div class="cl-ph-connector"></div>` : ""}
        <div class="cl-ph-item${item.isCurrent ? " cl-ph-current" : ""}">
          <span class="cl-ph-num">${circleNum(idx + 1)}</span>
          <div class="cl-ph-content">
            <span class="cl-ph-step-label">${item.label}${item.isCurrent ? " \u2014 Current" : ""}</span>
            <span class="cl-ph-text">\u201c${escapeHtml(truncated)}\u201d</span>
          </div>
          ${action}
        </div>`;
    }).join("") +
  `</div>`;
}

// Watch for new user messages — any new [data-testid="user-message"] means
// the user has sent a new turn, so the buffer should start fresh.
let _userMsgCount = 0;
const userMsgObserver = new MutationObserver(() => {
  const count = document.querySelectorAll('[data-testid="user-message"]').length;
  if (count > _userMsgCount) {
    _userMsgCount = count;
    resetWorkingPrompt();
  }
});
userMsgObserver.observe(document.body, { childList: true, subtree: true });

// ─── Tooltip singleton ───────────────────────────────────────────────────────

let tooltip          = null;
let lastTooltipEvent = null;
let lastTooltipData  = null;
let settingsPanelEl  = null;  // floating side panel for advanced view

function closeSettingsPanel() {
  if (!settingsPanelEl) return;
  settingsPanelEl.classList.remove("cl-settings-panel-visible");
  settingsPanelEl.addEventListener("transitionend", () => settingsPanelEl?.remove(), { once: true });
  settingsPanelEl = null;
}

function positionSettingsPanel() {
  if (!settingsPanelEl || !tooltip) return;
  const tr = tooltip.getBoundingClientRect();
  const gap = 10;
  const panelW = 270;
  settingsPanelEl.style.top   = tr.top + "px";
  settingsPanelEl.style.right = (window.innerWidth - tr.left + gap) + "px";
  settingsPanelEl.style.maxHeight = tooltip.style.maxHeight || (tr.height + "px");
}


function getOrCreateTooltip() {
  if (tooltip) return tooltip;

  tooltip = document.createElement("div");
  tooltip.className = "cl-tooltip";
  tooltip.style.display = "none";


  tooltip.addEventListener("mouseenter", () => {
    if (hideTimer) { clearTimeout(hideTimer); hideTimer = null; }
  });
  // Only auto-hide on mouseleave when not pinned
  tooltip.addEventListener("mouseleave", () => { if (!pinnedSpan) scheduleHide(80); });

  // Stop clicks inside the tooltip from bubbling to the document close-handler
  tooltip.addEventListener("click", (e) => e.stopPropagation());

  // Verify picker toggle — registered once here to avoid stacking on re-render
  tooltip.addEventListener("click", (e) => {
    const btn = e.target.closest(".cl-verify-trigger");
    if (btn) {
      const wrap   = btn.closest(".cl-verify-wrap");
      const picker = wrap.querySelector(".cl-verify-picker");
      const isOpen = picker.classList.toggle("cl-verify-picker-open");
      tooltip.querySelectorAll(".cl-verify-picker-open").forEach(p => {
        if (p !== picker) p.classList.remove("cl-verify-picker-open");
      });
      if (isOpen) requestAnimationFrame(clampToViewport);
      return;
    }
    if (!e.target.closest(".cl-verify-picker")) {
      tooltip.querySelectorAll(".cl-verify-picker-open").forEach(p => p.classList.remove("cl-verify-picker-open"));
    }
  }, true);

  // Re-clamp whenever the tooltip grows (e.g. after rewrite result is injected)
  new ResizeObserver(() => clampToViewport()).observe(tooltip);

  document.body.appendChild(tooltip);

  return tooltip;
}

function dismissTooltip() {
  if (hideTimer) { clearTimeout(hideTimer); hideTimer = null; }
  if (pinnedSpan) { pinnedSpan.classList.remove("cl-span-active"); }
  pinnedSpan = null;
  if (tooltip) {
    tooltip.style.display = "none";
    tooltip.classList.remove("cl-pinned");
  }
  closeSettingsPanel();
}

function scheduleHide(delay = 150) {
  if (pinnedSpan) return;          // never auto-hide while pinned
  if (hideTimer) clearTimeout(hideTimer);
  hideTimer = setTimeout(() => {
    if (!pinnedSpan && tooltip) tooltip.style.display = "none";
    hideTimer = null;
  }, delay);
}

// Close on click anywhere outside the tooltip and highlighted spans
document.addEventListener("click", (e) => {
  if (!tooltip || tooltip.style.display === "none") return;
  // Use composedPath() so detached nodes (removed by render() mid-click) still match
  const path = e.composedPath();
  if (path.includes(tooltip)) return;
  if (settingsPanelEl && path.includes(settingsPanelEl)) return; // keep open while settings panel is active
  if (e.target.closest("[data-certainty]")) return; // span clicks handled separately
  dismissTooltip();
});

// Returns the top of the Claude prompt input box, or viewport bottom as fallback.
function getPromptBoxTop() {
  const input = document.querySelector(
    "div[contenteditable='true'][data-placeholder], fieldset, form footer"
  );
  if (input) return input.getBoundingClientRect().top;
  return window.innerHeight - 80; // conservative fallback
}

function positionTooltip(_x, y) {
  const t = getOrCreateTooltip();
  const margin = 16;
  const promptTop = getPromptBoxTop();
  const availableHeight = promptTop - margin * 2;

  // Cap tooltip height to the space above the prompt box; enables scrolling within
  t.style.maxHeight = Math.max(200, availableHeight) + "px";

  const th = Math.min(t.scrollHeight || 400, availableHeight);
  let top = y - th / 2;
  top = Math.max(margin, Math.min(top, promptTop - th - margin));
  t.style.top = top + "px";
}

// Called after the browser has fully painted — corrects any overflow using real dimensions.
function clampToViewport() {
  const t = tooltip;
  if (!t || t.style.display === "none") return;
  const rect = t.getBoundingClientRect();
  const margin = 16;
  const promptTop = getPromptBoxTop();
  const availableHeight = promptTop - margin * 2;

  t.style.maxHeight = Math.max(200, availableHeight) + "px";

  if (rect.bottom > promptTop - margin) {
    t.style.top = Math.max(margin, promptTop - rect.height - margin) + "px";
  }
  if (parseFloat(t.style.top) < margin) {
    t.style.top = margin + "px";
  }
}

// ─── Client-side score recomputation (mirrors analyzer.js weights) ────────────

const PROSE_WEIGHTS_CLIENT = {
  citation: 0.72, medical: 0.70, legal: 0.65, qty: 0.62, model: 0.62,
  superlative: 0.58, negated: 0.50, claim: 0.45, temporal: 0.38, math: 0.30, hedge: 0.45,
};
const BASE_UNCERTAINTY_CLIENT = 0.08;

function recomputeCombined(scores) {
  const weighted = Object.entries(PROSE_WEIGHTS_CLIENT)
    .map(([k, w]) => (scores[k] ?? 0) / 100 * w)
    .filter(v => v > 0)
    .sort((a, b) => b - a);
  if (!weighted.length) return BASE_UNCERTAINTY_CLIENT;
  const primary = weighted[0];
  let secondary = 0;
  for (let i = 1; i < weighted.length; i++) secondary += weighted[i] * Math.pow(0.5, i);
  return Math.min(BASE_UNCERTAINTY_CLIENT + primary + Math.min(secondary, 0.20), 1.0);
}

// ─── Content type detection ───────────────────────────────────────────────────
// Unified model: only structural distinction is code (<pre>) vs prose.
// All prose runs the same pattern sets — no content-type routing.

function isCodeElement(el) {
  const tag = (el.tagName || "").toLowerCase();
  return tag === "pre" || tag === "code";
}

// ─── Tooltip rendering ───────────────────────────────────────────────────────

// Prose (unified): all 11 signal dimensions
const PROSE_CRITERIA = [
  {
    key:   "hedge",
    label: "Hedging language",
    desc:  "Qualifiers like \u2018I think\u2019, \u2018might\u2019, \u2018possibly\u2019 \u2014 Claude openly signalling its own uncertainty.",
    color: "#D08060",
    labels: { none: "None found", mild: "Slight uncertainty", mod: "Clearly hedging", high: "Heavy hedging" },
  },
  {
    key:   "claim",
    label: "Factual claims",
    desc:  "Specific verifiable facts \u2014 names, dates, statistics, or version numbers \u2014 that are easy to get wrong.",
    color: "#C0A040",
    labels: { none: "No specific claims", mild: "Minor claim", mod: "Specific claim made", high: "Risky specific claim" },
  },
  {
    key:   "temporal",
    label: "Temporal staleness",
    desc:  "References to \u2018currently\u2019, \u2018recently\u2019, or specific years. Claude has a knowledge cutoff, so these risk being outdated.",
    color: "#8AAE50",
    labels: { none: "Not time-sensitive", mild: "Slight dated risk", mod: "May be outdated", high: "Likely outdated" },
  },
  {
    key:   "citation",
    label: "Citation risk",
    desc:  "References to papers, authors, DOIs, or studies that Claude may have fabricated or misremembered.",
    color: "#9068C8",
    labels: { none: "No citations", mild: "General reference", mod: "Specific source cited", high: "Unverifiable source" },
  },
  {
    key:   "medical",
    label: "Medical claims",
    desc:  "Drug names, dosages, diagnoses, or clinical claims that could be harmful if wrong.",
    color: "#4E90B8",
    labels: { none: "No medical claims", mild: "General health info", mod: "Specific medical claim", high: "High-risk medical claim" },
  },
  {
    key:   "legal",
    label: "Legal claims",
    desc:  "Statutes, case citations, regulations, or legal interpretations that may be incorrect, repealed, or jurisdiction-specific.",
    color: "#4E9E68",
    labels: { none: "No legal claims", mild: "General legal ref", mod: "Specific legal claim", high: "Unverified legal claim" },
  },
  {
    key:   "math",
    label: "Mathematical claims",
    desc:  "Approximations (\u2248, \u2018roughly\u2019) or domain-constrained formulas where accuracy depends on unstated assumptions.",
    color: "#40ACAC",
    labels: { none: "No math claims", mild: "Slight approximation", mod: "Approximation used", high: "Heavy approximation" },
  },
  {
    key:   "superlative",
    label: "Superlative claims",
    desc:  "Statements using \u2018first\u2019, \u2018only\u2019, \u2018largest\u2019, \u2018best\u2019, or similar \u2014 claims that require exhaustive world knowledge to verify.",
    color: "#C87840",
    labels: { none: "No superlatives", mild: "Minor superlative", mod: "Strong superlative claim", high: "Unverifiable superlative" },
  },
  {
    key:   "qty",
    label: "Entity statistics",
    desc:  "Specific statistics or founding dates attributed to named entities \u2014 high hallucination risk for obscure or proprietary data.",
    color: "#6070C0",
    labels: { none: "No entity stats", mild: "General figure", mod: "Specific entity stat", high: "Precise unverified stat" },
  },
  {
    key:   "negated",
    label: "Negated claims",
    desc:  "Statements like \u2018does not cause\u2019 or \u2018there is no evidence\u2019 \u2014 models are measurably worse at negated factual claims.",
    color: "#A84848",
    labels: { none: "No negated claims", mild: "Mild negation", mod: "Negated factual claim", high: "Strong negated claim" },
  },
  {
    key:   "model",
    label: "Expert dispute risk",
    desc:  "Claude\u2019s self-assessment: whether domain experts would add important caveats or dispute this claim.",
    color: "#B05090",
    labels: { none: "Appears uncontested", mild: "Minor nuance", mod: "Warrants expert review", high: "Actively disputed" },
  },
];

// Code: 4-signal set (structural special case)
const CODE_CRITERIA = [
  { key: "hedge",    label: "Uncertain logic",    color: "#C0553A", desc: "TODO/FIXME comments or uncertainty markers indicating incomplete or untested implementation.", labels: { none: "No uncertainty markers", mild: "Minor comment", mod: "Uncertain logic noted", high: "Heavily uncertain" } },
  { key: "claim",    label: "API / package risk", color: "#B8720A", desc: "References to specific APIs, packages, or methods that may be hallucinated, renamed, or non-existent.", labels: { none: "No external refs", mild: "Minor dependency", mod: "Specific API used", high: "Unverified API calls" } },
  { key: "temporal", label: "Deprecation risk",   color: "#9A6B00", desc: "Code patterns, syntax, or library versions that may be outdated or deprecated.", labels: { none: "No deprecated patterns", mild: "Minor style issue", mod: "Likely outdated", high: "Deprecated pattern" } },
  { key: "model",    label: "Code review flags",  color: "#CF6C3F", desc: "Claude\u2019s assessment of potential edge cases, missing error handling, or logic bugs.", labels: { none: "Looks clean", mild: "Minor note", mod: "Warrants review", high: "Significant concern" } },
];

// Plain-English explanations for the top-scoring signal, used in simple view
const PROSE_SIMPLE_REASONS = {
  hedge: {
    why:    'Claude used qualifying language like <em>\u201cI think\u201d</em> or <em>\u201cmight\u201d</em> \u2014 which usually means it isn\u2019t fully confident in this claim.',
    action: "Ask Claude to explain its reasoning, or request that it cite a source.",
  },
  claim: {
    why:    "This sentence contains a specific fact \u2014 like a name, date, or number \u2014 that could be outdated or simply wrong.",
    action: "Verify this with an up-to-date source, or ask Claude where the information comes from.",
  },
  temporal: {
    why:    "This references something current or recent. Claude\u2019s knowledge has a cutoff date, so it may not reflect today\u2019s reality.",
    action: "Ask Claude to clarify when this information is from, or check a live source.",
  },
  citation: {
    why:    "This references a specific source, paper, or author that Claude may have fabricated or misremembered.",
    action: "Search for the source independently before relying on it \u2014 don\u2019t cite without verifying.",
  },
  medical: {
    why:    "This contains medical information \u2014 drug names, dosages, or clinical claims \u2014 that could be harmful if wrong.",
    action: "Verify with a qualified medical professional or official drug reference before acting on this.",
  },
  legal: {
    why:    "This makes a legal claim \u2014 citing laws, regulations, or case law \u2014 that may be incorrect, outdated, or jurisdiction-specific.",
    action: "Verify with an official legal source or consult a qualified attorney.",
  },
  math: {
    why:    "This contains mathematical approximations or domain-constrained formulas that may not hold in all cases.",
    action: "Ask Claude to specify the exact conditions under which this result holds, or to provide a primary source.",
  },
  superlative: {
    why:    "This sentence makes a superlative claim \u2014 \u2018first\u2019, \u2018only\u2019, \u2018largest\u2019, or similar \u2014 which requires exhaustive world knowledge that Claude may not have.",
    action: "Search for independent confirmation of this ranking or uniqueness claim.",
  },
  qty: {
    why:    "This attributes a specific statistic or founding date to a named entity. Claude frequently hallucinates precise figures for organisations and places.",
    action: "Verify this figure directly from the organisation\u2019s official source or a reputable database.",
  },
  negated: {
    why:    "This makes a negated factual claim (\u2018does not cause\u2019, \u2018there is no evidence\u2019). Research shows models are measurably less reliable at negated statements.",
    action: "Double-check the negation \u2014 search for any evidence that contradicts this denial.",
  },
  model: {
    why:    "Claude\u2019s internal assessment flagged this as likely to be disputed by domain experts or in need of additional caveats.",
    action: "Ask Claude how confident it is, and whether there\u2019s a primary source you can check.",
  },
};

const CODE_SIMPLE_REASONS = {
  hedge:    { why: "This code contains uncertainty markers (TODO/FIXME) suggesting it may be incomplete or untested.", action: "Ask Claude to complete the logic, add error handling, or confirm the approach is correct." },
  claim:    { why: "This code references specific APIs or packages that may not exist or may have changed.", action: "Verify these APIs exist in your environment and check the official docs." },
  temporal: { why: "This code uses patterns or syntax that may be outdated or deprecated in current versions.", action: "Ask Claude to update it to modern equivalents, or check the library\u2019s current docs." },
  model:    { why: "Claude\u2019s review flagged potential edge cases, missing error handling, or logic that could fail in practice.", action: "Ask Claude to add error handling, identify edge cases, and clarify its assumptions." },
};

function getPrimarySignal(scores) {
  if (!scores) return "model";
  return Object.keys(scores)
    .filter((k) => k !== "combined")
    .reduce((best, key) => ((scores[key] ?? 0) > (scores[best] ?? 0) ? key : best), "model");
}

function strengthLabel(pct, labels) {
  if (pct === 0)  return { text: labels.none, cls: "cl-str-none" };
  if (pct <= 29)  return { text: labels.mild, cls: "cl-str-mild" };
  if (pct <= 55)  return { text: labels.mod,  cls: "cl-str-mod"  };
  return                 { text: labels.high, cls: "cl-str-high" };
}

// Option A — simple tab: compact left-border row, name + status badge, no bar track
function renderBarSimple({ key, label, color }, pct, verifiedState = null) {
  const statusBadge = verifiedState === "verified"
    ? `<span class="cl-status-badge cl-status-validated">✓ Validated</span>`
    : verifiedState === "disputed"
    ? `<span class="cl-status-badge cl-status-contested">⚠ Contested</span>`
    : "";

  return `
    <div class="cl-simple-row" data-bar-key="${escapeAttr(key)}" style="border-left-color:${color}">
      <span class="cl-simple-row-label">${label}</span>
      ${statusBadge}
    </div>`;
}

// Option D — advanced tab: status badge leads, signal name below, thin accent bar at bottom
function renderBarAdvanced({ key, label, desc, color, labels }, pct, evidenceTags = [], verifiedState = null) {
  const width = Math.max(pct, 0);

  const statusBadge = verifiedState === "verified"
    ? `<span class="cl-status-badge cl-status-validated">✓ Validated</span>`
    : verifiedState === "disputed"
    ? `<span class="cl-status-badge cl-status-contested">⚠ Contested</span>`
    : "";

  const infoHtml = `
    <span class="cl-bar-info">
      <span class="cl-bar-info-icon">ⓘ</span>
      <div class="cl-bar-info-popup">${desc}</div>
    </span>`;

  const tagsHtml = evidenceTags.length ? (() => {
    const VISIBLE = 3;
    const visible = evidenceTags.slice(0, VISIBLE);
    const hidden  = evidenceTags.slice(VISIBLE);
    const visibleHtml = visible.map(t => `<span class="cl-evidence-tag">${escapeHtml(t)}</span>`).join("");
    const hiddenHtml  = hidden.length
      ? `<span class="cl-evidence-tag cl-evidence-hidden" style="display:none">${hidden.map(t => escapeHtml(t)).join(`</span><span class="cl-evidence-tag cl-evidence-hidden" style="display:none">`)}</span>
         <button class="cl-tags-toggle">[+${hidden.length}]</button>`
      : "";
    return `<div class="cl-bar-evidence">${visibleHtml}${hiddenHtml}</div>`;
  })() : "";

  return `
    <div class="cl-adv-bar-block" data-bar-key="${escapeAttr(key)}">
      <div class="cl-adv-bar-top">
        ${statusBadge}
        <div class="cl-adv-bar-label-group">
          <span class="cl-adv-bar-label">${label}</span>${infoHtml}
        </div>
      </div>
      ${tagsHtml}
      <div class="cl-adv-bar-track">
        <div class="cl-adv-bar-fill" style="width:${width}%;background:${color}"></div>
      </div>
    </div>`;
}

// Legacy alias — keeps call sites that pass simpleMode working during transition
function renderBar(criteria, pct, evidenceTags = [], simpleMode = false, verifiedState = null) {
  return simpleMode
    ? renderBarSimple(criteria, pct, verifiedState)
    : renderBarAdvanced(criteria, pct, evidenceTags, verifiedState);
}

// ─── Settings panel ───────────────────────────────────────────────────────────

const SIGNAL_LABELS = {
  citation:    "Citation risk",
  medical:     "Medical claims",
  legal:       "Legal claims",
  qty:         "Entity statistics",
  superlative: "Superlative claims",
  temporal:    "Temporal staleness",
  math:        "Mathematical claims",
  hedge:       "Uncertain language",
  negated:     "Negated claims",
  model:       "Expert dispute (AI check)",
};

function buildSettingsPanel(floating = false) {
  const panel = document.createElement("div");
  panel.className = floating ? "cl-settings-panel cl-settings-floating" : "cl-settings-panel";

  const render = () => {
    const activePreset = detectPreset();

    const toggle = (key, value, label) => `
      <div class="cl-setting-row">
        <span class="cl-setting-label">${label}</span>
        <button class="cl-toggle ${value ? "cl-toggle-on" : ""}" data-key="${key}">
          <span class="cl-toggle-knob"></span>
        </button>
      </div>`;

    const signalRows = Object.entries(SIGNAL_LABELS).map(([key, label]) =>
      toggle(`sig-${key}`, settings.signals[key] ?? true, label)
    ).join("");

    panel.innerHTML = `
      <div class="cl-settings-header">
        <span class="cl-settings-title">Settings</span>
        ${floating ? `<button class="cl-settings-close">✕</button>` : ""}
      </div>

      <div class="cl-settings-section">
        <div class="cl-settings-section-label">Preset</div>
        <div class="cl-preset-row">
          ${["essential","standard","thorough"].map(p => `
            <button class="cl-preset-btn${activePreset === p ? " cl-preset-active" : ""}" data-preset="${p}">
              ${p.charAt(0).toUpperCase() + p.slice(1)}
            </button>`).join("")}
        </div>
      </div>

      <div class="cl-settings-section">
        <div class="cl-settings-section-label">Signals</div>
        ${signalRows}
      </div>

      <div class="cl-settings-section">
        <div class="cl-settings-section-label">Sensitivity</div>
        <div class="cl-setting-row">
          <span class="cl-setting-label">Minimum tier to flag</span>
        </div>
        <div class="cl-tier-row">
          ${[["low","High-risk only"],["medium","Medium+"],["info","Everything"]].map(([v, l]) => `
            <button class="cl-tier-btn${settings.minTier === v ? " cl-tier-active" : ""}" data-tier="${v}">${l}</button>`).join("")}
        </div>
        ${toggle("showMultipliers", settings.showMultipliers, "Show risk multipliers")}
      </div>

      <div class="cl-settings-section">
        <div class="cl-settings-section-label">Verification</div>
        ${toggle("verification", settings.verification, "Background AI check")}
      </div>

    `;

    // Preset buttons
    panel.querySelectorAll(".cl-preset-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const cfg = PRESET_CONFIGS[btn.dataset.preset];
        settings.preset   = btn.dataset.preset;
        settings.signals  = { ...cfg.signals };
        settings.minTier  = cfg.minTier;
        settings.verification = cfg.verification;
        saveSettings();
        pruneStaleSpans();
        refreshOpenTooltip();
        render();
      });
    });

    // Toggle buttons (signals + verification + showCleanBar)
    panel.querySelectorAll(".cl-toggle").forEach(btn => {
      btn.addEventListener("click", () => {
        const key = btn.dataset.key;
        if (key.startsWith("sig-")) {
          const sig = key.slice(4);
          settings.signals[sig] = !settings.signals[sig];
        } else if (key === "verification") {
          settings.verification = !settings.verification;
        } else if (key === "showCleanBar") {
          settings.showCleanBar = !settings.showCleanBar;
        } else if (key === "showMultipliers") {
          settings.showMultipliers = !settings.showMultipliers;
        }
        settings.preset = detectPreset() ?? settings.preset;
        saveSettings();
        pruneStaleSpans();
        refreshOpenTooltip();
        render();
      });
    });

    // Min tier buttons
    panel.querySelectorAll(".cl-tier-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        settings.minTier = btn.dataset.tier;
        settings.preset  = detectPreset() ?? settings.preset;
        saveSettings();
        pruneStaleSpans();
        refreshOpenTooltip();
        render();
      });
    });

    // X close button (floating mode only)
    panel.querySelector(".cl-settings-close")?.addEventListener("click", () => {
      if (floating) closeSettingsPanel();
      else panel.remove();
    });
  };

  render();
  return panel;
}

// ─── Client-side score recomputation (mirrors analyzer.js logic) ─────────────
const CLIENT_WEIGHTS = {
  citation: 0.72, medical: 0.70, legal: 0.65, qty: 0.62, model: 0.62,
  superlative: 0.58, negated: 0.50, claim: 0.45, hedge: 0.45,
  temporal: 0.38, math: 0.30,
};

function recomputeAfterResolve(scores, resolvedKeys) {
  const BASE = 0.08;
  const weighted = Object.entries(CLIENT_WEIGHTS)
    .filter(([k]) => !resolvedKeys.has(k))
    .map(([k, w]) => ((scores[k] ?? 0) / 100) * w)
    .filter(v => v > 0)
    .sort((a, b) => b - a);

  if (!weighted.length) return BASE;
  const primary = weighted[0];
  let secondary = 0;
  for (let i = 1; i < weighted.length; i++) secondary += weighted[i] * Math.pow(0.5, i);
  return Math.min(BASE + primary + Math.min(secondary, 0.20), 1.0);
}

function combinedToCertainty(combined) {
  return combined >= 0.55 ? "low" : combined >= 0.20 ? "medium" : combined >= 0.10 ? "info" : "high";
}

// ─── Co-signal combination insights ──────────────────────────────────────────
// Checked in priority order — first match wins. Requires all listed keys to fire.
const COMBO_INSIGHTS = [
  {
    requires: ["citation", "medical"],
    title: "Citation + Medical",
    note: "A potentially fabricated study with clinical claims — the highest-risk combination. The paper may not exist and the dosage figures may have been invented independently to sound authoritative.",
  },
  {
    requires: ["citation", "legal"],
    title: "Citation + Legal",
    note: "An AI-generated legal citation is among the most dangerous output types. The case, statute, or regulation may be entirely fabricated alongside the legal conclusion drawn from it.",
  },
  {
    requires: ["medical", "legal"],
    title: "Medical + Regulatory",
    note: "A regulatory medical claim where both the clinical detail and its legal basis may be wrong. Errors here can have serious real-world consequences.",
  },
  {
    requires: ["citation", "qty"],
    title: "Citation + Statistics",
    note: "Specific figures attributed to a potentially fabricated source. The numbers and the citation may both be invented to create the appearance of evidence.",
  },
  {
    requires: ["superlative", "qty"],
    title: "Ranking + Statistics",
    note: "A ranked claim backed by specific figures. AI models frequently fabricate both the ranking and the supporting numbers — neither should be taken at face value.",
  },
  {
    requires: ["citation", "temporal"],
    title: "Citation + Temporal",
    note: "A time-sensitive claim from an unverifiable source. Even if the study exists, more recent research may have superseded its findings.",
  },
];

// ─── Per-signal verify links ───────────────────────────────────────────────────
// Words that should never be treated as named entities when building search queries.
const _ENTITY_STOP = new Set([
  "the","a","an","this","that","these","those","it","its","he","she","they","we",
  "in","on","at","to","for","of","with","by","from","as","into","about","over",
  "is","are","was","were","be","been","has","have","had","do","does","did",
  "will","would","could","should","may","might","must","can",
  "also","however","although","while","since","when","where","which","who",
  "their","his","her","our","my","your",
  "according","based","found","shown","noted","reported","suggests","indicates",
  "if","or","but","and","so","yet","nor","not","no",
  "new","old","first","second","third","last","next","other","another","one",
  "some","many","most","more","less","few","several","such","each",
]);

// Returns the best sequence of proper-noun tokens found in `s`, skipping
// sentence-initial articles and any tokens in _ENTITY_STOP.
function _extractEntity(s) {
  const re = /\b([A-Z][a-z]{2,}(?:\s+(?:[A-Z][a-z]{2,}|[A-Z]{2,6}))*)\b/g;
  let m;
  while ((m = re.exec(s)) !== null) {
    const first = m[1].split(/\s/)[0].toLowerCase();
    if (!_ENTITY_STOP.has(first)) return m[1];
  }
  return null;
}

// Builds a targeted search query per signal type from the flagged sentence.
function buildSearchQuery(sentence, signalKey) {
  const s = sentence || "";

  if (signalKey === "citation") {
    // 1. Quoted paper/book title — most reliable anchor
    const quoted = s.match(/"([^"]{10,100})"/)?.[1];
    if (quoted) {
      const year = s.match(/\b((?:19|20)\d{2})\b/)?.[0] ?? "";
      return [quoted, year].filter(Boolean).join(" ");
    }

    // 2. Author-year proximity: "Smith (2019)", "Smith et al. (2019)", "Smith, 2019"
    // Requires a proper surname (≥3 lowercase chars) immediately before the year.
    const authorYear = s.match(
      /\b([A-Z][a-z]{2,}(?:\s+et\s+al\.?)?)\s*[,(]\s*((?:19|20)\d{2})/
    );
    if (authorYear) {
      const journal = s.match(
        /\b(?:Journal|Review|Nature|Science|Lancet|NEJM|BMJ|JAMA|Cell|PNAS|Proceedings|Annals|Archives|Frontiers|PLOS)\b[^,.;\n]*/i
      )?.[0];
      return [authorYear[1], authorYear[2], journal].filter(Boolean).join(" ");
    }

    // 3. Journal name + year
    const journal = s.match(
      /\b(?:Journal|Review|Nature|Science|Lancet|NEJM|BMJ|JAMA|Cell|PNAS|Proceedings|Annals|Archives|Frontiers|PLOS)\b[^,.;\n]*/i
    )?.[0];
    const year = s.match(/\b((?:19|20)\d{2})\b/)?.[0];
    if (journal && year) return `${journal} ${year}`;

    // 4. Sentence fallback — always better than bad extraction
    return s.slice(0, 160);
  }

  if (signalKey === "medical") {
    const drug = s.match(
      /\b\w+(?:mab|statin|pril|olol|azole|mycin|cillin|cycline|sartan|prazole|tidine|vir|umab|zumab)\b/i
    ) || s.match(
      /\b(?:aspirin|ibuprofen|acetaminophen|paracetamol|metformin|insulin|warfarin|heparin|morphine|codeine|fentanyl|naloxone|prednisone|amoxicillin|penicillin|ivermectin|hydroxychloroquine)\b/i
    ) || s.match(
      /\b(?:vaccine|vaccination|GLP-1|semaglutide|ozempic|wegovy|mounjaro|keytruda|humira|dupixent)\b/i
    );
    const dose = s.match(/\b\d+(?:\.\d+)?\s*(?:mg|mcg|ml|units?|IU)\b/i);
    const condition = s.match(
      /\b(?:diabetes|cancer|obesity|depression|anxiety|autism|COVID|HIV|hypertension|arthritis|Alzheimer|Parkinson|stroke|cardiovascular|tumor)\b/i
    );
    const parts = [drug?.[0], dose?.[0], condition?.[0]].filter(Boolean);
    return parts.length ? parts.join(" ") : s.slice(0, 100);
  }

  if (signalKey === "legal") {
    const caseMatch    = s.match(/[A-Z][a-z]+\s+v\.?\s+[A-Z][a-z]+/);
    const statute      = s.match(/\d+\s+U\.S\.C\.\s*§?\s*\d+|\d+\s+C\.F\.R[^,.\s]*/);
    const act          = s.match(/[A-Z][A-Za-z\s]{2,40}Act(?:\s+of\s+\d{4})?/);
    const reg          = s.match(/\b(?:GDPR|HIPAA|CCPA|SOX|FERPA|ADA|OSHA|FCPA|FINRA|FTC|SEC)\b/);
    const parts        = [caseMatch?.[0], statute?.[0], act?.[0], reg?.[0]].filter(Boolean);
    return parts.length ? parts.join(" ") : s.slice(0, 120);
  }

  if (signalKey === "temporal") {
    // Strip staleness markers, then strip any leading article so we get
    // "current Apple revenue 2023" not "current the Apple revenue 2023"
    const stripped = s
      .replace(/\bas\s+of\s+(?:early|late|mid-?)?\s*(?:(?:19|20)\d{2})?\b/gi, "")
      .replace(/\baccording\s+to\s+(?:recent|current|latest)\s+(?:data|research|studies|reports?)\b/gi, "")
      .replace(/\b(?:recently|currently|nowadays|at\s+present)\b/gi, "")
      .replace(/^[\s,]+/, "")
      .trim();
    const core = stripped.replace(/^(?:the|a|an|this|that|in|at|on)\s+/i, "").trim();
    return `current ${core.slice(0, 110)}`;
  }

  if (signalKey === "qty") {
    const num    = s.match(/\b(\d[\d,\.]*(?:\s*(?:percent|million|billion|trillion|thousand|hundred|%))?)/i)?.[1];
    const entity = _extractEntity(s);
    if (entity && num) return `${entity} ${num} fact check`;
    if (entity)        return `${entity} statistics fact check`;
    return `${s.slice(0, 120)} fact check`;
  }

  if (signalKey === "superlative") {
    const entity    = _extractEntity(s);
    const supMatch  = s.match(
      /\b(?:first|only|largest|biggest|smallest|most\s+\w+|best|worst|oldest|newest|fastest|slowest|richest|highest|lowest|leading|top)\b/i
    )?.[0];
    if (entity && supMatch) return `${entity} ${supMatch} fact check`;
    if (entity)             return `${entity} fact check`;
    return `${s.slice(0, 120)} fact check`;
  }

  if (signalKey === "negated") {
    // Strip negation framing to expose the underlying claim, then search for it
    const stripped = s
      .replace(/\bthere\s+(?:is|are|was|were)\s+no\s+(?:evidence|proof|data|studies?|research)\s+(?:that|to\s+suggest|linking|connecting)\s*/gi, "")
      .replace(/\b(?:does?\s+not|do\s+not|did\s+not|is\s+not|are\s+not|was\s+not|were\s+not|cannot|can't|doesn't|isn't|aren't|wasn't|weren't)\s*/gi, " ")
      .replace(/\bno\s+(?:known|significant|direct|causal|clear)\s+/gi, "")
      .replace(/\s{2,}/g, " ")
      .trim();
    const base = stripped.slice(0, 120);
    // Only append "evidence" if the word isn't already present
    return /\bevidence\b/i.test(base) ? base : `${base} evidence`;
  }

  return s.slice(0, 140);
}

const VERIFY_LINKS = {
  citation:    (q) => [
    { icon: "🎓", label: "Google Scholar", url: `https://scholar.google.com/scholar?q=${encodeURIComponent(q)}` },
    { icon: "🧬", label: "Semantic Scholar", url: `https://www.semanticscholar.org/search?q=${encodeURIComponent(q)}&sort=Relevance` },
    { icon: "📄", label: "PubMed",         url: `https://pubmed.ncbi.nlm.nih.gov/?term=${encodeURIComponent(q)}` },
  ],
  medical:     (q) => [
    { icon: "💊", label: "FDA DailyMed",   url: `https://dailymed.nlm.nih.gov/dailymed/search.cfm?labeltype=all&query=${encodeURIComponent(q)}` },
    { icon: "🧬", label: "PubMed",         url: `https://pubmed.ncbi.nlm.nih.gov/?term=${encodeURIComponent(q)}` },
    { icon: "🏥", label: "drugs.com",      url: `https://www.drugs.com/search.php?searchterm=${encodeURIComponent(q)}` },
  ],
  legal:       (q) => [
    { icon: "⚖️", label: "Justia",         url: `https://law.justia.com/search?q=${encodeURIComponent(q)}` },
    { icon: "🎓", label: "Scholar (legal)", url: `https://scholar.google.com/scholar?q=${encodeURIComponent(q)}&as_sdt=4,5` },
  ],
  qty:         (q) => [
    { icon: "🔍", label: "Fact-check",     url: `https://www.google.com/search?q=${encodeURIComponent(q)}` },
  ],
  superlative: (q) => [
    { icon: "🔍", label: "Fact-check",     url: `https://www.google.com/search?q=${encodeURIComponent(q)}` },
  ],
  temporal:    (q) => [
    { icon: "🔍", label: "Check current",  url: `https://www.google.com/search?q=${encodeURIComponent(q)}` },
  ],
  negated:     (q) => [
    { icon: "🧬", label: "PubMed",         url: `https://pubmed.ncbi.nlm.nih.gov/?term=${encodeURIComponent(q)}` },
    { icon: "🎓", label: "Google Scholar", url: `https://scholar.google.com/scholar?q=${encodeURIComponent(q)}` },
  ],
};

function showTooltip(event, data) {
  const t = getOrCreateTooltip();
  if (hideTimer) { clearTimeout(hideTimer); hideTimer = null; }
  lastTooltipEvent = event;
  lastTooltipData  = data;

  const { certainty, details, scores, signals, sentenceText, contentType = "natural", associatedPrompt, verification = {}, verifyExplain = {}, _span } = data;

  // ── Config based on code vs prose ──
  const isCode       = contentType === "code";
  const allCriteria   = isCode ? CODE_CRITERIA : PROSE_CRITERIA;
  // Filter criteria to only enabled signals (settings don't apply to code view)
  const criteria      = isCode ? allCriteria : allCriteria.filter(c => settings.signals[c.key] !== false);
  const simpleReasons = isCode ? CODE_SIMPLE_REASONS : PROSE_SIMPLE_REASONS;

  // ── Shared header values ──
  const icon = certainty === "low" ? "⚠" : certainty === "medium" ? "△" : "○";

  // ── Simple view ──
  const primaryKey = getPrimarySignal(scores);
  const { why, action } = (simpleReasons[primaryKey] ?? SIMPLE_REASONS[primaryKey]);

  // ── Advanced view ──
  // Remap the bar so it's anchored to the certainty bucket, not a raw linear score.
  // This prevents the bar from showing "88% confident" alongside orange/red signals.
  const rawCombined = (scores?.combined ?? 0) / 100;
  let confPct;
  if (certainty === "high") {
    confPct = Math.round(100 - (rawCombined / 0.10) * 5);            // 100 → 95
  } else if (certainty === "info") {
    confPct = Math.round(95 - ((rawCombined - 0.10) / 0.10) * 15);  // 95 → 80
  } else if (certainty === "medium") {
    confPct = Math.round(80 - ((rawCombined - 0.20) / 0.35) * 40);  // 80 → 40
  } else {
    confPct = Math.round(35 - ((rawCombined - 0.55) / 0.45) * 30);  // 35 → 5
  }
  confPct = Math.max(5, Math.min(100, confPct));
  // Pre-resolved signals for this sentence (persisted across sessions/tabs)
  const sKey = sentenceKey(sentenceText);
  const preResolved = new Set(resolvedCache[sKey] ?? []);

  // Compute display certainty accounting for any already-resolved signals
  const displayCertainty = preResolved.size > 0
    ? combinedToCertainty(recomputeAfterResolve(scores ?? {}, preResolved))
    : certainty;

  const confClass = displayCertainty === "high"   ? "cl-conf-high"
                  : displayCertainty === "info"   ? "cl-conf-info"
                  : displayCertainty === "medium" ? "cl-conf-med"
                  : "cl-conf-low";
  const confLabel = displayCertainty === "high"   ? "Low risk"
                  : displayCertainty === "info"   ? "Flag: minor"
                  : displayCertainty === "medium" ? "Flag: moderate"
                  : "Flag: high risk";
  // Only render bars that fired (score > 0), sorted by score descending so the
  // highest-risk signal always appears first.
  const barsHtml = scores
    ? criteria
        .filter((c) => (scores[c.key] ?? 0) > 0)
        .sort((a, b) => (scores[b.key] ?? 0) - (scores[a.key] ?? 0))
        .map((c) => renderBar(c, scores[c.key], signals?.[c.key] ?? [], false, verification?.[c.key] ?? null))
        .join("")
    : "";

  const originalPrompt = associatedPrompt ?? getLastUserPrompt();

  const activeSignalCount = criteria
    .filter(c => !preResolved.has(c.key))
    .filter(c => (scores?.[c.key] ?? 0) > 0).length;

  const improveBtnLabel = (n) => n > 0
    ? `Refine prompt · address ${n} signal${n !== 1 ? "s" : ""}`
    : `Refine prompt`;

  const improvePanelHtml = (radioName, showRadio = true) => `
    <div class="cl-improve-panel">
      <div class="cl-improve-header">Improve this prompt</div>
      ${buildHistoryHtml(originalPrompt)}
      ${showRadio ? `
      <div class="cl-improve-radios">
        <label class="cl-improve-opt">
          <input type="radio" name="${radioName}" value="integrate" checked>
          <div class="cl-improve-opt-body">
            <span class="cl-improve-opt-title">Quick tweak</span>
            <span class="cl-improve-opt-hint">Minimal edits to original</span>
          </div>
        </label>
        <label class="cl-improve-opt">
          <input type="radio" name="${radioName}" value="rewrite">
          <div class="cl-improve-opt-body">
            <span class="cl-improve-opt-title">Full rewrite</span>
            <span class="cl-improve-opt-hint">Rewritten for clarity</span>
          </div>
        </label>
      </div>` : ""}
      <button class="cl-improve-btn" data-sentence="${escapeAttr(sentenceText || "")}" data-prompt="${escapeAttr(originalPrompt)}">${improveBtnLabel(activeSignalCount)}</button>
      <div class="cl-tt-rewrite-result" style="display:none"></div>
    </div>`;

  // Store scores + resolved state on the element for use in resolve handlers
  t._scores = scores ?? {};
  t._sKey = sKey;
  t._resolvedKeys = new Set(preResolved); // start with any already-persisted resolutions

  t.innerHTML = `
    <div class="cl-tt-header">
      <img src="${chrome.runtime.getURL("signal_cut_icon.svg")}" class="cl-brand-icon" alt="">
      <span class="cl-tt-spinner" aria-hidden="true"></span>
      <span class="cl-tt-header-right">
        <span class="cl-tt-verdict ${confClass}">${confLabel}</span>
        <button class="cl-tt-close" aria-label="Close">✕</button>
      </span>
    </div>
    <div class="cl-tt-tabs">
      <button class="cl-tab-opt${activeView === "simple"   ? " cl-tab-active" : ""}" data-view="simple">Simple</button>
      <button class="cl-tab-opt${activeView === "advanced" ? " cl-tab-active" : ""}" data-view="advanced">Advanced</button>
      <button class="cl-gear-btn" title="Settings">⚙</button>
    </div>

    <!-- Simple view -->
    <div class="cl-view cl-view-simple" style="display:${activeView === "simple" ? "block" : "none"}">
      ${(() => {
        const activeSignals = criteria
          .filter(c => !preResolved.has(c.key))
          .filter(c => (scores?.[c.key] ?? 0) > 0)
          .sort((a, b) => (scores[b.key] ?? 0) - (scores[a.key] ?? 0));

        const summaryChips = activeSignals.map(c =>
          `<span class="cl-summary-chip" style="color:${c.color}">${c.label.toLowerCase()}</span>`
        );
        const summaryHtml = summaryChips.length > 1
          ? `This sentence was flagged for ${summaryChips.slice(0,-1).join(", ")} and ${summaryChips[summaryChips.length-1]}.`
          : summaryChips.length === 1
          ? `This sentence was flagged for ${summaryChips[0]}.`
          : "This sentence contains content worth verifying.";

        const accordionRows = activeSignals
          .map(c => {
            const r = simpleReasons[c.key];
            const v = verification?.[c.key];
            const isValidated = v === "verified";
            const statusBadge = v === "disputed"
              ? `<span class="cl-status-badge cl-status-contested">⚠ Contested</span>` : "";
            const explainRaw  = verifyExplain?.[c.key] || "";
            const explainText = buildValidatedTooltip(c.label, explainRaw);
            const leftEl = isValidated
              ? `<span class="cl-validated-cell" data-explain="${escapeAttr(explainText)}">✓ Validated</span>`
              : `<button class="cl-resolve-btn">✓</button><span class="cl-resolve-label cl-resolve-label-simple">Resolve</span>`;
            return `
              <div class="cl-accordion" data-key="${escapeAttr(c.key)}" data-color="${escapeAttr(c.color)}">
                <div class="cl-accordion-header" style="border-left-color:${c.color}">
                  ${leftEl}
                  <span class="cl-accordion-label">${c.label}</span>
                  <div class="cl-accordion-right">${statusBadge}<span class="cl-accordion-chevron">›</span></div>
                </div>
                <div class="cl-accordion-body">${r ? r.why : ""}</div>
              </div>`;
          }).join("");

        return `
          <div class="cl-simple-block">
            <div class="cl-simple-label">Why flagged</div>
            <div class="cl-simple-summary">${summaryHtml}</div>
          </div>
          ${accordionRows.length ? `<div class="cl-simple-accordions">${accordionRows}</div>` : ""}`;
      })()}
      ${improvePanelHtml("cl-mode-s", false)}
    </div>

    <!-- Advanced view — unified per-signal cards combining bar + explanation + verify note -->
    <div class="cl-view cl-view-advanced" style="display:${activeView === "advanced" ? "block" : "none"}">
      ${(() => {
        // Parse the details string into a map of key → explanation text
        const detailsByKey = {};
        if (details) {
          details.split("\n\n").forEach(para => {
            const match = para.match(/^\[(\w+)\]([\s\S]*)$/);
            if (match) detailsByKey[match[1]] = match[2].trim();
          });
        }

        const verifyNote = (key) => {
          const v = verification?.[key];
          if (v === "disputed")
            return `<div class="cl-verify-note cl-verify-note-contested"><span class="cl-verify-note-name">${criteria.find(c=>c.key===key)?.label ?? key}</span><span class="cl-status-badge cl-status-contested">⚠ Contested</span><span class="cl-verify-note-desc">A background check found experts would dispute or caveat this claim.</span></div>`;
          return "";
        };

        const firedCriteria = criteria
          .filter(c => !preResolved.has(c.key))
          .filter(c => (scores?.[c.key] ?? 0) > 0)
          .sort((a, b) => (scores[b.key] ?? 0) - (scores[a.key] ?? 0));

        if (!firedCriteria.length) return `<div class="cl-adv-empty">No signals detected.</div>`;

        // ── Risk Multipliers ───────────────────────────────────────────────────
        const firedKeys = new Set(firedCriteria.map(c => c.key));
        const matchedCombos = COMBO_INSIGHTS.filter(ci => ci.requires.every(k => firedKeys.has(k)));
        const highWeightFired = firedCriteria.filter(c =>
          ["citation","medical","legal","qty","superlative","negated"].includes(c.key)
        );
        // Add generic catch-all only when 3+ high-weight signals fire and no specific combo covered them
        const allCoveredKeys = new Set(matchedCombos.flatMap(ci => ci.requires));
        const uncoveredHigh  = highWeightFired.filter(c => !allCoveredKeys.has(c.key));
        const showGeneric    = uncoveredHigh.length >= 3;

        const multiplierBlocks = [
          ...matchedCombos.map(ci => `
            <div class="cl-multiplier" data-requires="${ci.requires.join(",")}">
              <div class="cl-multiplier-header">
                <span class="cl-multiplier-title">⚡ ${escapeHtml(ci.title)}</span>
                <span class="cl-multiplier-chevron">›</span>
              </div>
              <div class="cl-multiplier-body">${escapeHtml(ci.note)}</div>
            </div>`),
          showGeneric ? `
            <div class="cl-multiplier" data-requires="${uncoveredHigh.map(c => c.key).join(",")}">
              <div class="cl-multiplier-header">
                <span class="cl-multiplier-title">⚡ Multiple high-risk signals</span>
                <span class="cl-multiplier-chevron">›</span>
              </div>
              <div class="cl-multiplier-body">Three or more high-risk signals co-fired. Treat every specific claim in this sentence as unverified before acting on it.</div>
            </div>` : "",
        ].filter(Boolean).join("");

        const multipliersSection = (multiplierBlocks && settings.showMultipliers)
          ? `<div class="cl-simple-label" style="padding:10px 14px 0">Risk Multipliers</div>
             <div class="cl-risk-multipliers">${multiplierBlocks}</div>`
          : "";

        // ── Per-signal cards ───────────────────────────────────────────────────
        const cards = firedCriteria.map(c => {
          const pct        = scores?.[c.key] ?? 0;
          const v          = verification?.[c.key];
          const expl       = detailsByKey[c.key] ?? "";
          const tags       = signals?.[c.key] ?? [];
          const advExplain = verifyExplain?.[c.key] || "";
          const statusBadge = v === "verified"
            ? `<span class="cl-status-badge cl-status-validated" data-explain="${escapeAttr(buildValidatedTooltip(c.label, advExplain))}">✓ Validated</span>`
            : v === "disputed"
            ? `<span class="cl-status-badge cl-status-contested">⚠ Contested</span>`
            : "";

          const tagsHtml = tags.length ? (() => {
            const VISIBLE = 3;
            const vis = tags.slice(0, VISIBLE).map(t => `<span class="cl-evidence-tag">${escapeHtml(t)}</span>`).join("");
            const hid = tags.slice(VISIBLE);
            const hidHtml = hid.length
              ? `<span class="cl-evidence-tag cl-evidence-hidden" style="display:none">${hid.map(t=>escapeHtml(t)).join('</span><span class="cl-evidence-tag cl-evidence-hidden" style="display:none">')}</span><button class="cl-tags-toggle">[+${hid.length}]</button>`
              : "";
            return `<div class="cl-bar-evidence">${vis}${hidHtml}</div>`;
          })() : "";

          const infoHtml = `<span class="cl-bar-info"><span class="cl-bar-info-icon">ⓘ</span><div class="cl-bar-info-popup">${c.desc}</div></span>`;

          const links = VERIFY_LINKS[c.key]?.(buildSearchQuery(sentenceText, c.key)) ?? [];
          const hasPerpCheck = ["citation", "medical", "legal"].includes(c.key);
          const pickerHtml = v === "verified" ? statusBadge : ((links.length || hasPerpCheck) ? `
            <div class="cl-verify-wrap">
              ${statusBadge}
              <button class="cl-verify-trigger">Verify ↗</button>
              <div class="cl-verify-picker">
                ${links.length ? `<div class="cl-verify-picker-label">Search with</div>
                ${links.map(l => `
                  <a class="cl-verify-picker-row" href="${l.url}" target="_blank" rel="noopener noreferrer">
                    <span class="cl-verify-picker-icon">${l.icon}</span>
                    <span>${escapeHtml(l.label)}</span>
                  </a>`).join("")}` : ""}
                ${hasPerpCheck ? `
                <button class="cl-verify-picker-row cl-perp-trigger${links.length ? " cl-perp-divider" : ""}" data-sentence="${escapeAttr(sentenceText || "")}">
                  <span class="cl-verify-picker-icon">✦</span>
                  <span>Live check (Perplexity)</span>
                </button>` : ""}
              </div>
            </div>` : statusBadge);

          return `
            <div class="cl-adv-card" data-key="${escapeAttr(c.key)}" data-color="${escapeAttr(c.color)}" style="border-left-color:${c.color}${v === "verified" ? ";opacity:0.55" : ""}">
              <div class="cl-adv-card-header">
                <div class="cl-adv-card-title-row">
                  <span class="cl-adv-card-label" style="color:${c.color}">${c.label}</span>
                  ${infoHtml}
                  ${v !== "verified" ? `<div class="cl-adv-card-bar"><div class="cl-adv-card-fill" style="width:${pct}%;background:${c.color}"></div></div>` : ""}
                  ${v !== "verified" ? `<span class="cl-adv-card-pct" style="color:${c.color}">${pct}%</span>` : ""}
                </div>
                ${pickerHtml}
              </div>
              ${expl ? `<div class="cl-adv-card-expl">${escapeHtml(expl)}</div>` : ""}
              ${tagsHtml}
              ${verifyNote(c.key)}
              <div class="cl-fc-card-result" style="display:none"></div>
              <div class="cl-adv-card-footer">
                <span class="cl-resolve-label">Resolve</span>
                <button class="cl-resolve-btn">✓</button>
              </div>
            </div>`;
        }).join("");

        return `${multipliersSection}<div class="cl-simple-label" style="padding:10px 14px 0">Signal breakdown</div><div class="cl-adv-cards">${cards}</div>`;
      })()}
      ${improvePanelHtml("cl-mode-a", false)}
    </div>
  `;

  // Resolve buttons — dismiss signal from both views, recompute overall score
  t.querySelectorAll(".cl-resolve-btn").forEach(btn => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const source = btn.closest(".cl-adv-card") || btn.closest(".cl-accordion");
      if (!source) return;
      const key = source.dataset.key;
      if (!key) return;

      // Mark as resolved and persist
      t._resolvedKeys.add(key);
      resolvedCache[t._sKey] = [...t._resolvedKeys];
      chrome.storage.local.set({ clResolved: resolvedCache });

      // Show loading spinner while recomputing
      const spinner = t.querySelector(".cl-tt-spinner");
      if (spinner) spinner.classList.add("cl-tt-spinner-active");

      // Fade out all elements with this key across both views
      t.querySelectorAll(`[data-key="${key}"]`).forEach(el => {
        el.style.transition = "opacity 0.2s, transform 0.2s";
        el.style.opacity = "0";
        el.style.transform = "translateX(6px)";
        setTimeout(() => el.remove(), 200);
      });

      setTimeout(() => {
        // Fade out any risk multipliers that required the resolved signal
        t.querySelectorAll(".cl-multiplier[data-requires]").forEach(el => {
          const reqs = el.dataset.requires.split(",");
          if (reqs.includes(key)) {
            el.style.transition = "opacity 0.2s, transform 0.2s";
            el.style.opacity = "0";
            el.style.transform = "translateX(6px)";
            setTimeout(() => {
              el.remove();
              // Hide the Risk Multipliers header if none remain
              const rmWrap = t.querySelector(".cl-risk-multipliers");
              if (rmWrap && !rmWrap.querySelector(".cl-multiplier")) {
                const label = rmWrap.previousElementSibling;
                if (label?.classList.contains("cl-simple-label")) label.remove();
                rmWrap.remove();
              }
            }, 200);
          }
        });

        // Empty-state checks
        const cards = t.querySelector(".cl-adv-cards");
        if (cards && !cards.querySelector(".cl-adv-card")) {
          cards.innerHTML = `<div class="cl-adv-empty">All signals resolved.</div>`;
        }
        const accordions = t.querySelector(".cl-simple-accordions");
        if (accordions && !accordions.querySelector(".cl-accordion")) {
          accordions.innerHTML = `<div class="cl-resolved-empty">All flags resolved.</div>`;
        }

        // Rebuild "Why flagged" summary from remaining active signals
        const remaining = criteria
          .filter(c => !t._resolvedKeys.has(c.key) && (scores?.[c.key] ?? 0) > 0)
          .sort((a, b) => (scores[b.key] ?? 0) - (scores[a.key] ?? 0));
        const chips = remaining.map(c =>
          `<span class="cl-summary-chip" style="color:${c.color}">${c.label.toLowerCase()}</span>`
        );
        const newSummary = chips.length > 1
          ? `This sentence was flagged for ${chips.slice(0, -1).join(", ")} and ${chips[chips.length - 1]}.`
          : chips.length === 1
          ? `This sentence was flagged for ${chips[0]}.`
          : `<span style="color:#6BBF87">All flags resolved.</span>`;
        const summaryEl = t.querySelector(".cl-simple-summary");
        if (summaryEl) summaryEl.innerHTML = newSummary;

        // If all signals resolved — remove the underline and unregister the span
        if (remaining.length === 0 && _span) {
          _span.classList.remove("cl-uncertain-high", "cl-uncertain-medium", "cl-uncertain-info");
          _span.removeAttribute("data-certainty");
          // Update the response bar count and refine button for this container
          const barContainer = _span.closest("[data-is-streaming]");
          if (barContainer) updateResponseBar(barContainer);
        }

        // Recompute combined score from remaining signals
        const newCombined = recomputeAfterResolve(t._scores, t._resolvedKeys);
        const newCertainty = combinedToCertainty(newCombined);

        // Update verdict pill
        const pill = t.querySelector(".cl-tt-verdict");
        if (pill) {
          pill.className = `cl-tt-verdict cl-conf-${newCertainty === "high" ? "high" : newCertainty === "info" ? "info" : newCertainty === "medium" ? "med" : "low"}`;
          pill.textContent = newCertainty === "high" ? "Low risk"
            : newCertainty === "info"   ? "Flag: minor"
            : newCertainty === "medium" ? "Flag: moderate"
            : "Flag: high risk";
        }

        // Update "Refine prompt" button label in both improve panels
        const activeCount = remaining.length;
        t.querySelectorAll(".cl-improve-btn").forEach(btn => {
          if (!btn.disabled) {
            btn.textContent = activeCount > 0
              ? `Refine prompt · address ${activeCount} signal${activeCount !== 1 ? "s" : ""}`
              : "Refine prompt";
          }
        });

        // Hide spinner once recompute is done
        if (spinner) spinner.classList.remove("cl-tt-spinner-active");

        requestAnimationFrame(clampToViewport);
      }, 220);
    });
  });

  // Risk Multiplier dropdowns
  t.querySelectorAll(".cl-multiplier-header").forEach(header => {
    header.addEventListener("click", () => {
      const item = header.closest(".cl-multiplier");
      item.classList.toggle("cl-multiplier-open");
      requestAnimationFrame(clampToViewport);
    });
  });

  // Accordion signal rows in simple view
  t.querySelectorAll(".cl-accordion").forEach(row => {
    const color = row.dataset.color;
    row.querySelector(".cl-accordion-header").addEventListener("click", (e) => {
      if (e.target.closest(".cl-resolve-btn")) return;
      const isOpen = row.classList.toggle("cl-accordion-open");
      // Tint the whole row with the signal color when open
      row.style.background = isOpen ? `${color}0d` : "";
      row.style.borderColor = isOpen ? `${color}30` : "";
      requestAnimationFrame(clampToViewport);
    });
  });

  // Toggle between simple / advanced — persist selection across spans
  t.querySelectorAll(".cl-tab-opt").forEach((btn) => {
    btn.addEventListener("click", () => {
      activeView = btn.dataset.view;
      t.querySelectorAll(".cl-tab-opt").forEach((b) => b.classList.remove("cl-tab-active"));
      btn.classList.add("cl-tab-active");
      t.querySelector(".cl-view-simple").style.display   = activeView === "simple"   ? "block" : "none";
      t.querySelector(".cl-view-advanced").style.display = activeView === "advanced" ? "block" : "none";
      closeSettingsPanel();
      positionTooltip(event.clientX, event.clientY);
      requestAnimationFrame(clampToViewport);
    });
  });

  // Gear button — floating side panel to the left for both views
  t.querySelector(".cl-gear-btn").addEventListener("click", () => {
    if (settingsPanelEl) { closeSettingsPanel(); return; }
    settingsPanelEl = buildSettingsPanel(true);
    document.body.appendChild(settingsPanelEl);
    positionSettingsPanel();
    requestAnimationFrame(() => settingsPanelEl?.classList.add("cl-settings-panel-visible"));
  });

  // Wire evidence tag toggles
  t.querySelectorAll(".cl-tags-toggle").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const block = btn.closest(".cl-bar-evidence");
      block.querySelectorAll(".cl-evidence-hidden").forEach(el => el.style.display = "inline-flex");
      btn.remove();
      requestAnimationFrame(clampToViewport);
    });
  });

  // Wire improve buttons (both views have their own panel)
  t.querySelectorAll(".cl-improve-btn").forEach((btn) => btn.addEventListener("click", handleRewrite));

  // Wire history timeline buttons
  t.querySelectorAll(".cl-ph-reset").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      resetWorkingPrompt();
      showTooltip(event, data);
      if (pinnedSpan) tooltip.classList.add("cl-pinned");
    });
  });

  t.querySelectorAll(".cl-ph-use").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      // Roll back history to this version
      const target = btn.dataset.prompt;
      const idx = promptHistory.findIndex(h => h.text === target);
      promptHistory = idx >= 0 ? promptHistory.slice(0, idx + 1) : [];
      showTooltip(event, data);
      if (pinnedSpan) tooltip.classList.add("cl-pinned");
    });
  });

  // Perplexity live check from verify picker
  t.querySelectorAll(".cl-perp-trigger").forEach(btn => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      btn.closest(".cl-verify-picker")?.classList.remove("cl-verify-picker-open");
      const card = btn.closest(".cl-adv-card");
      const resultEl = card?.querySelector(".cl-fc-card-result");
      if (!resultEl) return;

      const cardColor = card.dataset.color || "#9A8E82";
      const hexRgba = (hex, a) => {
        const [r, g, b] = hex.replace("#","").match(/../g).map(h => parseInt(h, 16));
        return `rgba(${r},${g},${b},${a})`;
      };

      btn.disabled = true;
      resultEl.style.background  = hexRgba(cardColor, 0.08);
      resultEl.style.borderTop   = `1px solid ${hexRgba(cardColor, 0.20)}`;
      resultEl.innerHTML = `<span class="cl-fc-checking">Checking with Perplexity…</span>`;
      resultEl.style.display = "block";
      requestAnimationFrame(clampToViewport);

      chrome.runtime.sendMessage({ type: "PERPLEXITY_VERIFY", sentence: btn.dataset.sentence }, (resp) => {
        btn.disabled = false;
        if (!resp?.ok) {
          resultEl.innerHTML = `<span class="cl-fc-error">Check failed — try again.</span>`;
          requestAnimationFrame(clampToViewport);
          return;
        }
        const { verdict, verdict_reason, sources } = resp.data;
        const iconClass = verdict === "supported"    ? "cl-fc-icon-support"
                        : verdict === "contradicted" ? "cl-fc-icon-contradict"
                        : "cl-fc-icon-unknown";
        const icon = verdict === "supported" ? "✓" : verdict === "contradicted" ? "✗" : "?";
        const sourcesHtml = (sources || []).slice(0, 3).map(s => `
          <a class="cl-fc-source" href="${escapeAttr(s.url || "")}" target="_blank" rel="noopener noreferrer"
             style="background:${hexRgba(cardColor,0.05)};border-color:${hexRgba(cardColor,0.16)}">
            <span class="cl-fc-source-title" style="color:${cardColor}">${escapeHtml(s.title || "Source")}</span>
            ${s.snippet ? `<span class="cl-fc-source-snippet">${escapeHtml(s.snippet)}</span>` : ""}
          </a>`).join("");
        resultEl.innerHTML = `
          <div class="cl-fc-verdict-row">
            <span class="${iconClass}">${icon}</span>
            <span class="cl-fc-reason">${escapeHtml(verdict_reason || "")}</span>
          </div>
          ${sourcesHtml ? `<div class="cl-fc-sources">${sourcesHtml}</div>` : ""}`;
        requestAnimationFrame(clampToViewport);
      });
    });
  });

  // Wire hover sub-tooltip for ✓ Validated badges
  let _explainEl = null;
  t.querySelectorAll("[data-explain]").forEach(badge => {
    badge.addEventListener("mouseenter", (e) => {
      if (_explainEl) _explainEl.remove();
      _explainEl = document.createElement("div");
      _explainEl.className = "cl-validated-subtip";
      _explainEl.textContent = badge.dataset.explain;
      document.body.appendChild(_explainEl);
      const r = badge.getBoundingClientRect();
      const tipW = 240;
      let left = r.left + r.width / 2 - tipW / 2;
      if (left < 8) left = 8;
      if (left + tipW > window.innerWidth - 8) left = window.innerWidth - tipW - 8;
      _explainEl.style.left = `${left}px`;
      // Position above badge; fall back to below if too close to top
      const spaceAbove = r.top - 8;
      if (spaceAbove >= 80) {
        _explainEl.style.top  = `${r.top + window.scrollY - 8}px`;
        _explainEl.style.transform = "translateY(-100%)";
      } else {
        _explainEl.style.top  = `${r.bottom + window.scrollY + 6}px`;
        _explainEl.style.transform = "none";
      }
    });
    badge.addEventListener("mouseleave", () => {
      if (_explainEl) { _explainEl.remove(); _explainEl = null; }
    });
  });

  t.querySelector(".cl-tt-close")?.addEventListener("click", dismissTooltip);

  t.style.display = "block";
  // First pass: position based on best available height estimate.
  requestAnimationFrame(() => positionTooltip(event.clientX, event.clientY));
  // Second pass: correct using real post-paint dimensions (setTimeout fires after paint).
  setTimeout(clampToViewport, 0);
}

// ─── Rewrite handler ─────────────────────────────────────────────────────────

function getLastUserPrompt() {
  const msgs = document.querySelectorAll('[data-testid="user-message"]');
  return msgs.length ? msgs[msgs.length - 1].innerText.trim() : "";
}

// Find the user message that immediately precedes `el` in document order.
// Uses compareDocumentPosition so it works regardless of Claude's DOM structure.
function getPromptForElement(el) {
  const allUserMsgs = [...document.querySelectorAll('[data-testid="user-message"]')];
  if (!allUserMsgs.length) return "";

  // Walk backwards through user messages; return the first one that appears
  // before `el` in the document (i.e. el follows it).
  for (let i = allUserMsgs.length - 1; i >= 0; i--) {
    const msg = allUserMsgs[i];
    // DOCUMENT_POSITION_FOLLOWING (4) means el comes after msg
    if (msg.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING) {
      return msg.innerText.trim();
    }
  }

  return allUserMsgs[0].innerText.trim();
}

// Inject text into Claude's composer input.
// Claude uses a contenteditable ProseMirror div; data-testid="chat-input" wraps it.
function injectIntoClaudeInput(text) {
  // The actual editable element is a contenteditable inside the chat-input container
  const container = document.querySelector('[data-testid="chat-input"]');
  const editable  = container
    ? container.querySelector('[contenteditable="true"]') ?? container
    : document.querySelector('[contenteditable="true"]:not([class*="message"]):not([data-is-streaming])');

  if (!editable) return false;

  editable.focus();

  // Select all existing content and replace
  const sel = window.getSelection();
  sel.selectAllChildren(editable);
  document.execCommand("insertText", false, text);

  // Fallback if execCommand didn't work (some browsers)
  if (editable.innerText.trim() !== text.trim()) {
    editable.innerText = text;
    editable.dispatchEvent(new Event("input", { bubbles: true }));
  }

  // Move cursor to end
  sel.selectAllChildren(editable);
  sel.collapseToEnd();
  return true;
}

function submitClaudeInput() {
  const sendBtn =
    document.querySelector('button[aria-label="Send message"]') ||
    document.querySelector('[data-testid="send-button"]') ||
    document.querySelector('[data-testid="chat-input"] button:not([aria-label])');
  if (sendBtn && !sendBtn.disabled) sendBtn.click();
}

function showOnboarding(span) {
  if (document.querySelector(".cl-onboard-tip")) return;
  const tip = document.createElement("div");
  tip.className = "cl-onboard-tip";
  tip.innerHTML = `
    <div class="cl-onboard-caret"></div>
    <div class="cl-onboard-title">InCite found potential issues</div>
    <div class="cl-onboard-body">Click any <span class="cl-onboard-hl">highlighted text</span> to see what was flagged and why — and get a refined prompt.</div>
    <button class="cl-onboard-dismiss">Got it</button>
  `;
  document.body.appendChild(tip);

  const reposition = () => {
    if (!span.isConnected) { tip.remove(); return; }
    const rect = span.getBoundingClientRect();
    const tipW = 220;
    let left = rect.left + rect.width / 2 - tipW / 2 + window.scrollX;
    left = Math.max(8, Math.min(left, window.innerWidth - tipW - 8));
    tip.style.left = `${left}px`;
    tip.style.top  = `${rect.bottom + window.scrollY + 10}px`;
    const caret = tip.querySelector(".cl-onboard-caret");
    const caretCenter = rect.left + rect.width / 2 + window.scrollX - left;
    caret.style.left = `${Math.max(12, Math.min(caretCenter, tipW - 12))}px`;
  };
  reposition();

  const dismiss = () => {
    tip.remove();
    chrome.storage.local.set({ clOnboarded: true });
  };
  tip.querySelector(".cl-onboard-dismiss").addEventListener("click", dismiss);
  window.addEventListener("scroll", () => tip.remove(), { once: true, passive: true });
}

function handleRewrite(e) {
  const btn             = e.currentTarget;
  const flaggedSentence = btn.dataset.sentence;
  const prompt          = btn.dataset.prompt || getLastUserPrompt();
  const panel           = btn.closest(".cl-improve-panel");
  const resultEl        = panel.querySelector(".cl-tt-rewrite-result");
  const radio           = panel.querySelector('input[type="radio"]:checked');
  const mode            = radio?.value ?? "auto";

  const origLabel     = btn.textContent;
  btn.disabled        = true;
  btn.textContent     = "Working\u2026";
  resultEl.style.display = "none";

  const effectivePrompt = currentWorkingPrompt() ?? prompt;

  try {
    chrome.runtime.sendMessage(
      { type: "REWRITE", prompt: effectivePrompt, flaggedSentence, mode },
      (response) => {
        btn.disabled    = false;
        btn.textContent = origLabel;

        if (response?.ok && response.data?.rewritten) {
          const rewritten    = response.data.rewritten;
          const responseMode = response.data.mode ?? (mode === "auto" ? "rewrite" : mode);

          // Word-level diff between what was sent and what came back
          const ops     = wordDiff(effectivePrompt, rewritten);
          const added   = ops.filter(o => o.k === "a" && o.t.trim()).length;
          const removed = ops.filter(o => o.k === "r" && o.t.trim()).length;
          const stat    = added && removed ? `${added} added, ${removed} removed`
                        : added   ? `${added} word${added   !== 1 ? "s" : ""} added`
                        : removed ? `${removed} word${removed !== 1 ? "s" : ""} removed`
                        : "Rephrased";

          resultEl.style.display = "block";
          resultEl.innerHTML = `
            <div class="cl-diff-header">
              <span class="cl-diff-badge">${modeLabel(responseMode)}</span>
              <span class="cl-diff-stat">${stat}</span>
            </div>
            <div class="cl-diff-text">${renderDiff(ops)}</div>
            <div class="cl-diff-actions">
              <button class="cl-tt-use-btn">\u2192 Apply</button>
              <button class="cl-diff-copy-btn">\u2398 Copy</button>
            </div>
          `;

          resultEl.querySelector(".cl-tt-use-btn").addEventListener("click", () => {
            if (injectIntoClaudeInput(rewritten)) {
              promptHistory.push({ text: rewritten, mode: responseMode });
              setTimeout(() => {
                if (tooltip) tooltip.style.display = "none";
                submitClaudeInput();
              }, 150);
            }
          });

          resultEl.querySelector(".cl-diff-copy-btn").addEventListener("click", (ev) => {
            const copyBtn = ev.currentTarget;
            navigator.clipboard.writeText(rewritten).then(() => {
              copyBtn.textContent = "Copied!";
              setTimeout(() => { copyBtn.textContent = "\u2398 Copy"; }, 1500);
            }).catch(() => {
              copyBtn.textContent = "Failed";
              setTimeout(() => { copyBtn.textContent = "\u2398 Copy"; }, 1500);
            });
          });

        } else {
          resultEl.style.display = "block";
          resultEl.innerHTML = `<div class="cl-diff-text" style="color:#f08080">Could not generate suggestion. Is the API running?</div>`;
        }
        setTimeout(clampToViewport, 0);
      }
    );
  } catch {
    btn.disabled    = false;
    btn.textContent = origLabel;
  }
}

// ─── Escape helpers ──────────────────────────────────────────────────────────

function escapeHtml(str) {
  return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function escapeAttr(str) {
  return str.replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

// Builds the tooltip text for a ✓ Validated badge.
// signalLabel: human-readable signal name (e.g. "Citations", "Medical claims")
// explainRaw:  one-sentence explanation from verifier.js, may be empty
function buildValidatedTooltip(signalLabel, explainRaw) {
  const what = `${signalLabel} signal`;
  const how  = "checked by a secondary AI pass against training knowledge";
  const result = explainRaw
    ? explainRaw.charAt(0).toUpperCase() + explainRaw.slice(1).replace(/\.?\s*$/, ".")
    : "No issues found.";
  return `${what} — ${how}. ${result} Note: training knowledge only, not live sources.`;
}

// ─── Highlight injection ─────────────────────────────────────────────────────

const TIER_ORDER = ["high", "info", "medium", "low"];

function tierMeetsMin(tier) {
  return TIER_ORDER.indexOf(tier) >= TIER_ORDER.indexOf(settings.minTier);
}

function applyHighlightsToP(p, segments) {
  if (!segments.some((s) => s.certainty !== "high")) return;

  const original = p.innerText;
  let html = "", cursor = 0;

  for (const seg of segments) {
    if (seg.start > cursor) html += escapeHtml(original.slice(cursor, seg.start));

    const cls =
      seg.certainty === "low"    ? "cl-uncertain-high"   :
      seg.certainty === "medium" ? "cl-uncertain-medium" :
      seg.certainty === "info"   ? "cl-uncertain-info"   : "";

    // Skip wrap if below minTier or all fired signals are disabled
    const enabledSignalFired = cls && Object.keys(settings.signals).some(
      k => settings.signals[k] && (seg.scores?.[k] ?? 0) > 0
    );
    const shouldWrap = cls && tierMeetsMin(seg.certainty) && enabledSignalFired;

    if (shouldWrap) {
      const s  = seg.scores   ?? {};
      const si = seg.signals  ?? {};
      const primaryKey = getPrimarySignal(s);
      const signalColor = PROSE_CRITERIA.find(c => c.key === primaryKey)?.color ?? "#C0B8AE";
      html += `<span
        class="${cls}"
        data-certainty="${seg.certainty}"
        style="--cl-signal-color:${signalColor}"
        data-content-type="${seg.contentType ?? "natural"}"
        data-details="${escapeAttr(seg.details || "")}"
        data-sentence="${escapeAttr(seg.text)}"
        data-score-hedge="${s.hedge ?? 0}"
        data-score-claim="${s.claim ?? 0}"
        data-score-temporal="${s.temporal ?? 0}"
        data-score-citation="${s.citation ?? 0}"
        data-score-medical="${s.medical ?? 0}"
        data-score-legal="${s.legal ?? 0}"
        data-score-math="${s.math ?? 0}"
        data-score-superlative="${s.superlative ?? 0}"
        data-score-qty="${s.qty ?? 0}"
        data-score-negated="${s.negated ?? 0}"
        data-score-model="${s.model ?? 0}"
        data-score-combined="${s.combined ?? 0}"
        data-sig-hedge="${escapeAttr((si.hedge ?? []).join(","))}"
        data-sig-claim="${escapeAttr((si.claim ?? []).join(","))}"
        data-sig-temporal="${escapeAttr((si.temporal ?? []).join(","))}"
        data-sig-citation="${escapeAttr((si.citation ?? []).join(","))}"
        data-sig-medical="${escapeAttr((si.medical ?? []).join(","))}"
        data-sig-legal="${escapeAttr((si.legal ?? []).join(","))}"
        data-sig-math="${escapeAttr((si.math ?? []).join(","))}"
        data-sig-superlative="${escapeAttr((si.superlative ?? []).join(","))}"
        data-sig-qty="${escapeAttr((si.qty ?? []).join(","))}"
        data-sig-negated="${escapeAttr((si.negated ?? []).join(","))}"
        data-sig-model="${escapeAttr((si.model ?? []).join(","))}"
      >${escapeHtml(seg.text)}</span>`;
    } else {
      html += escapeHtml(seg.text);
    }
    cursor = seg.end;
  }

  if (cursor < original.length) html += escapeHtml(original.slice(cursor));
  p.innerHTML = html;

  const associatedPrompt = getPromptForElement(p);

  p.querySelectorAll("[data-certainty]").forEach((span) => {
    const splitTags = (s) => s ? s.split(",").filter(Boolean) : [];
    const getVerification  = (key) => span.dataset[`verified${key.charAt(0).toUpperCase()}${key.slice(1)}`] || null;
    const getVerifyExplain = (key) => span.dataset[`verifyExplain${key.charAt(0).toUpperCase()}${key.slice(1)}`] || null;
    const VERIFIABLE_KEYS = ["citation", "medical", "legal", "claim", "qty", "superlative", "negated", "temporal", "math", "hedge", "model"];

    const getData = () => ({
      certainty:    span.dataset.certainty,
      contentType:  span.dataset.contentType ?? "natural",
      details:      span.dataset.details,
      sentenceText: span.dataset.sentence,
      associatedPrompt,
      scores: {
        hedge:    Number(span.dataset.scoreHedge),
        claim:    Number(span.dataset.scoreClaim),
        temporal: Number(span.dataset.scoreTemporal),
        citation: Number(span.dataset.scoreCitation),
        medical:  Number(span.dataset.scoreMedical),
        legal:    Number(span.dataset.scoreLegal),
        math:        Number(span.dataset.scoreMath),
        superlative: Number(span.dataset.scoreSuperlative),
        qty:         Number(span.dataset.scoreQty),
        negated:     Number(span.dataset.scoreNegated),
        model:       Number(span.dataset.scoreModel),
        combined:    Number(span.dataset.scoreCombined),
      },
      signals: {
        hedge:       splitTags(span.dataset.sigHedge),
        claim:       splitTags(span.dataset.sigClaim),
        temporal:    splitTags(span.dataset.sigTemporal),
        citation:    splitTags(span.dataset.sigCitation),
        medical:     splitTags(span.dataset.sigMedical),
        legal:       splitTags(span.dataset.sigLegal),
        math:        splitTags(span.dataset.sigMath),
        superlative: splitTags(span.dataset.sigSuperlative),
        qty:         splitTags(span.dataset.sigQty),
        negated:     splitTags(span.dataset.sigNegated),
        model:       splitTags(span.dataset.sigModel),
      },
      verification:  Object.fromEntries(VERIFIABLE_KEYS.map(k => [k, getVerification(k)])),
      verifyExplain: Object.fromEntries(VERIFIABLE_KEYS.map(k => [k, getVerifyExplain(k)])),
      _span: span,
    });

    span._clGetData = getData;

    span.addEventListener("click", (e) => {
      e.stopPropagation();
      if (pinnedSpan === span) {
        // Second click on the same span → dismiss
        dismissTooltip();
      } else {
        // Un-pin the old span, pin this one
        if (pinnedSpan) pinnedSpan.classList.remove("cl-span-active");
        pinnedSpan = span;
        span.classList.add("cl-span-active");
        showTooltip(e, getData());
        getOrCreateTooltip().classList.add("cl-pinned");
      }
    });
  });
}

// ─── Code / line-level highlight ─────────────────────────────────────────────
// Highlights individual flagged lines using Range-based overlay divs so syntax
// highlighting is never disturbed.

function findTextRange(root, segStart, segEnd) {
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  let chars = 0, startNode = null, startOff = 0, endNode = null, endOff = 0, node;
  while ((node = walker.nextNode())) {
    const len = node.textContent.length;
    if (!startNode && chars + len > segStart) { startNode = node; startOff = segStart - chars; }
    if (startNode  && chars + len >= segEnd)  { endNode   = node; endOff   = segEnd   - chars; break; }
    chars += len;
  }
  if (!startNode) return null;
  if (!endNode)   { endNode = startNode; endOff = startNode.textContent.length; }
  try {
    const r = document.createRange();
    r.setStart(startNode, Math.min(startOff, startNode.textContent.length));
    r.setEnd(endNode,     Math.min(endOff,   endNode.textContent.length));
    return r;
  } catch { return null; }
}

function applyHighlightsToPre(pre, segments) {
  const flaggedSegments = segments.filter(s => s.certainty !== "high");
  if (!flaggedSegments.length) return;

  const associatedPrompt = getPromptForElement(pre);
  if (getComputedStyle(pre).position === "static") pre.style.position = "relative";

  for (const seg of flaggedSegments) {
    const range = findTextRange(pre, seg.start, seg.end);
    if (!range) continue;

    const preRect = pre.getBoundingClientRect();
    const segRect = range.getBoundingClientRect();
    if (!segRect.height) continue;

    const overlay = document.createElement("div");
    overlay.className = seg.certainty === "low" ? "cl-code-line-high" : "cl-code-line-med";
    overlay.style.top    = `${segRect.top - preRect.top + pre.scrollTop}px`;
    overlay.style.height = `${segRect.height}px`;

    const getData = () => ({
      certainty:    seg.certainty,
      contentType:  "code",
      details:      seg.details ?? "",
      sentenceText: seg.text,
      associatedPrompt,
      scores:       seg.scores  ?? {},
      signals:      seg.signals ?? {},
    });

    overlay.addEventListener("mouseenter", (e) => {
      if (pinnedSpan && pinnedSpan !== overlay) return;
      overlay.classList.add("cl-span-hover");
      showTooltip(e, getData());
    });
    overlay.addEventListener("mouseleave", () => {
      overlay.classList.remove("cl-span-hover");
      if (!pinnedSpan) scheduleHide(150);
    });
    overlay.addEventListener("mousemove", (e) => {
      if (!pinnedSpan) positionTooltip(e.clientX, e.clientY);
    });
    overlay.addEventListener("click", (e) => {
      e.stopPropagation();
      if (pinnedSpan === overlay) {
        dismissTooltip();
      } else {
        if (pinnedSpan) pinnedSpan.classList.remove("cl-span-active");
        pinnedSpan = overlay;
        overlay.classList.add("cl-span-active");
        showTooltip(e, getData());
        getOrCreateTooltip().classList.add("cl-pinned");
      }
    });

    pre.appendChild(overlay);
  }
}

// ─── Analysis pipeline ───────────────────────────────────────────────────────

function sendToBackground(type, payload) {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage({ type, ...payload }, (response) => {
        if (chrome.runtime.lastError) {
          const msg = chrome.runtime.lastError.message ?? "";
          if (msg.includes("Extension context invalidated")) observer.disconnect();
          resolve(null);
        } else {
          resolve(response?.ok ? response.data : null);
        }
      });
    } catch {
      observer.disconnect();
      resolve(null);
    }
  });
}

function applyVerificationToSpan(span, results) {
  for (const { type, verdict, explanation, scoreMultiplier } of results) {
    // Store verdict and explanation
    const key = type.charAt(0).toUpperCase() + type.slice(1);
    span.dataset[`verified${key}`]      = verdict;
    span.dataset[`verifyExplain${key}`] = explanation;

    // Apply multiplier to signal score
    const scoreKey = `score${key}`;
    if (span.dataset[scoreKey] !== undefined) {
      span.dataset[scoreKey] = Math.round(Number(span.dataset[scoreKey]) * scoreMultiplier);
    }
  }

  // Recompute combined score client-side
  const updatedScores = {
    hedge: Number(span.dataset.scoreHedge), claim: Number(span.dataset.scoreClaim),
    temporal: Number(span.dataset.scoreTemporal), citation: Number(span.dataset.scoreCitation),
    medical: Number(span.dataset.scoreMedical), legal: Number(span.dataset.scoreLegal),
    math: Number(span.dataset.scoreMath), superlative: Number(span.dataset.scoreSuperlative),
    qty: Number(span.dataset.scoreQty), negated: Number(span.dataset.scoreNegated),
    model: Number(span.dataset.scoreModel),
  };
  const newCombined = recomputeCombined(updatedScores);
  span.dataset.scoreCombined = Math.round(newCombined * 100);

  // Update certainty tier and highlight class
  const newCertainty = newCombined >= 0.55 ? "low" : newCombined >= 0.20 ? "medium" : newCombined >= 0.10 ? "info" : "high";

  // If the flag is fully cleared, unwrap the span — replace with plain text so
  // hover and click no longer trigger anything.
  if (newCertainty === "high") {
    if (pinnedSpan === span) dismissTooltip();
    const textNode = document.createTextNode(span.textContent);
    span.parentNode?.replaceChild(textNode, span);
    return;
  }

  span.dataset.certainty = newCertainty;
  span.classList.remove("cl-uncertain-high", "cl-uncertain-medium", "cl-uncertain-info");
  if (newCertainty === "low")         span.classList.add("cl-uncertain-high");
  else if (newCertainty === "medium") span.classList.add("cl-uncertain-medium");
  else if (newCertainty === "info")   span.classList.add("cl-uncertain-info");
}

// Eagerly verify all flagged prose spans right after analysis so results are
// ready by the time the user opens the tooltip.
// Highlights are hidden (cl-verifying on parent) until all requests settle.
// onAllDone fires once every pending request has resolved.
function eagerVerifySpans(el, onAllDone) {
  const spans = [...el.querySelectorAll("[data-certainty='low'], [data-certainty='medium'], [data-certainty='info']")];
  if (!spans.length) { onAllDone?.(); return; }

  el.classList.add("cl-verifying");
  let pending = 0;

  const oneDone = () => {
    pending--;
    if (pending <= 0) {
      el.classList.remove("cl-verifying");
      onAllDone?.();
    }
  };

  spans.forEach((span) => {
    if (span.dataset.clVerifying === "1") return;
    const anyVerified = PROSE_CRITERIA.some(
      (c) => span.dataset[`verified${c.key.charAt(0).toUpperCase()}${c.key.slice(1)}`]
    );
    if (anyVerified) return;

    const firedSignals = PROSE_CRITERIA
      .filter((c) => Number(span.dataset[`score${c.key.charAt(0).toUpperCase()}${c.key.slice(1)}`]) > 0)
      .map((c) => ({
        type:   c.key,
        labels: (span.dataset[`sig${c.key.charAt(0).toUpperCase()}${c.key.slice(1)}`] || "").split(",").filter(Boolean),
      }));

    if (!firedSignals.length) return;

    pending++;
    span.dataset.clVerifying = "1";
    const sentenceText = span.dataset.sentence;

    chrome.runtime.sendMessage(
      { type: "VERIFY", sentence: sentenceText, signals: firedSignals },
      (response) => {
        delete span.dataset.clVerifying;
        if (response?.ok && response.data?.results) {
          applyVerificationToSpan(span, response.data.results);
          if (span.isConnected && pinnedSpan === span && lastTooltipEvent && span._clGetData) {
            showTooltip(lastTooltipEvent, span._clGetData());
            getOrCreateTooltip().classList.add("cl-pinned");
          }
        }
        oneDone();
      }
    );
  });

  // If nothing actually queued (all skipped), fire immediately
  if (pending === 0) { el.classList.remove("cl-verifying"); onAllDone?.(); }
}

// analyzeElement returns a Promise that resolves once verification is complete
// (or immediately for code elements). processResponseContainer waits on all of
// them before inserting the response bar so the flag count reflects post-
// validation state.
async function analyzeElement(el) {
  if (processed.has(el)) return;
  processed.add(el);

  const text = el.innerText.trim();
  if (!text || text.length < 20) return;

  const contentType = isCodeElement(el) ? "code" : "natural";
  const data = await sendToBackground("ANALYZE", { text, contentType });
  if (!data?.segments?.length) return;

  if (contentType === "code") {
    applyHighlightsToPre(el, data.segments);
  } else {
    applyHighlightsToP(el, data.segments);
    // Return a promise that resolves when all verification requests settle
    return new Promise((resolve) => eagerVerifySpans(el, resolve));
  }
}

async function processResponseContainer(container) {
  if (processing.has(container)) return;
  if (_barByContainer.has(container) || container.querySelector(".cl-response-bar")) return;
  processing.add(container);
  try {
    const elements = [...container.querySelectorAll("p, pre")];
    if (elements.length > 0) {
      await Promise.all(elements.map(analyzeElement));
    } else if (!processed.has(container)) {
      await analyzeElement(container);
    }
    // Insert bar only after verification has settled — count reflects validated state
    insertResponseBar(container);
  } finally {
    processing.delete(container);
  }
}

function buildResponseDashboard(container, triggerBtn) {
  // Toggle: remove if already open
  const existing = document.querySelector(".cl-dashboard");
  if (existing) {
    existing.remove();
    triggerBtn?.classList.remove("cl-bar-active");
    return;
  }

  const spans = [...container.querySelectorAll("[data-certainty='low'], [data-certainty='medium'], [data-certainty='info']")];
  if (!spans.length) return;

  const dashboard = document.createElement("div");
  dashboard.className = "cl-dashboard";

  const items = spans.map((span, idx) => {
    const certainty = span.dataset.certainty;
    const scores = {};
    ["hedge","claim","temporal","citation","medical","legal","math","superlative","qty","negated","model"].forEach(k => {
      scores[k] = Number(span.dataset[`score${k.charAt(0).toUpperCase()}${k.slice(1)}`] || 0);
    });
    const primaryKey = getPrimarySignal(scores);
    const criterion = PROSE_CRITERIA.find(c => c.key === primaryKey);
    const text = (span.dataset.sentence || span.innerText || "").trim();
    const preview = text.length > 90 ? text.slice(0, 90) + "…" : text;
    const dotColor = certainty === "low" ? "#D96860" : certainty === "medium" ? "#D4941A" : "#AABF60";
    return `
      <div class="cl-dash-item" data-idx="${idx}" tabindex="0">
        <span class="cl-dash-sev-dot" style="background:${dotColor};flex-shrink:0"></span>
        <div class="cl-dash-content">
          <span class="cl-dash-signal" style="color:${criterion?.color || '#888'}">${criterion?.label || primaryKey}</span>
          <span class="cl-dash-text">${escapeHtml(preview)}</span>
        </div>
        <span class="cl-dash-arrow">›</span>
      </div>`;
  }).join("");

  dashboard.innerHTML = `
    <div class="cl-dash-header">
      <span class="cl-dash-title">${spans.length} flag${spans.length !== 1 ? "s" : ""} in this response</span>
      <button class="cl-dash-close">✕</button>
    </div>
    <div class="cl-dash-list">${items}</div>
  `;

  // Insert at the end of the response container (before the bar if it's still inside)
  const barInContainer = container.querySelector(".cl-response-bar");
  if (barInContainer) {
    container.insertBefore(dashboard, barInContainer);
  } else {
    container.appendChild(dashboard);
  }
  triggerBtn?.classList.add("cl-bar-active");

  dashboard.querySelectorAll(".cl-dash-item").forEach((item) => {
    const idx = Number(item.dataset.idx);
    item.addEventListener("click", () => {
      const span = spans[idx];
      if (!span?.isConnected) return;
      dashboard.remove();
      triggerBtn?.classList.remove("cl-bar-active");
      span.scrollIntoView({ behavior: "smooth", block: "center" });
      setTimeout(() => span.dispatchEvent(new MouseEvent("click", { bubbles: true })), 250);
    });
  });

  dashboard.querySelector(".cl-dash-close").addEventListener("click", () => {
    dashboard.remove();
    triggerBtn?.classList.remove("cl-bar-active");
  });
}

// Find Claude's native action bar (thumbs up/down/copy/regenerate row) near the container.
// Returns the element to append our bar into, or null if not found.
function findClaudeActionBar(container) {
  const sel = [
    'button[aria-label*="Thumbs"]',
    'button[aria-label*="Good response"]',
    'button[aria-label*="Bad response"]',
    'button[aria-label*="Regenerate"]',
    'button[data-testid*="feedback"]',
  ].join(', ');
  let el = container.parentElement;
  for (let d = 0; d < 5; d++) {
    if (!el) break;
    for (const child of el.children) {
      if (!child.contains(container) && child !== container && child.querySelector(sel)) return child;
    }
    el = el.parentElement;
  }
  return null;
}

function insertResponseBar(container) {
  if (_barByContainer.has(container)) return; // already inserted

  const flagged = [...container.querySelectorAll("[data-certainty='low'], [data-certainty='medium'], [data-certainty='info']")];
  const bar = document.createElement("div");
  bar.className = "cl-response-bar";

  if (!flagged.length) {
    bar.innerHTML = `<span class="cl-response-bar-clean">✓ No flags detected in this response</span>`;
    container.appendChild(bar);
    _barByContainer.set(container, bar);
    if (!settings.showCleanBar) bar.style.display = "none";
    return;
  }

  const prompt = getPromptForElement(container) || getLastUserPrompt();
  const count  = flagged.length;
  const logoUrl = chrome.runtime.getURL("signal_cut_icon.svg");

  bar.innerHTML = `
    <button class="cl-bar-flag-btn" aria-label="View all flags">
      <img src="${logoUrl}" class="cl-bar-logo" alt="">
      <span class="cl-response-bar-label">✦ <span class="cl-flag-count">${count}</span> flag${count !== 1 ? "s" : ""} detected</span>
      <span class="cl-bar-chevron">⌃</span>
    </button>
    <button class="cl-refine-all-btn">Refine prompt · address ${count > 1 ? `all ${count} flags` : "1 flag"}</button>
  `;

  const flagBtn = bar.querySelector(".cl-bar-flag-btn");
  flagBtn.addEventListener("click", () => buildResponseDashboard(container, flagBtn));

  bar.querySelector(".cl-refine-all-btn").addEventListener("click", async (e) => {
    const btn = e.currentTarget;
    btn.disabled = true;
    btn.textContent = "Refining…";

    const SIGNAL_LABELS = {
      citation:    "citation risk",
      medical:     "medical claims",
      legal:       "legal/regulatory claims",
      math:        "math or numeric errors",
      superlative: "superlative/absolute claims",
      qty:         "quantity/statistics",
      negated:     "negated claims",
      temporal:    "temporal staleness",
      hedge:       "hedged language",
      claim:       "factual claims",
      model:       "model self-reference",
    };
    const flaggedSentences = [...container.querySelectorAll("[data-certainty='low'], [data-certainty='medium'], [data-certainty='info']")]
      .map(span => {
        const firedSignals = Object.entries(SIGNAL_LABELS)
          .filter(([key]) => Number(span.dataset[`score${key.charAt(0).toUpperCase()}${key.slice(1)}`] ?? 0) > 0)
          .map(([, label]) => label);
        return {
          text: span.dataset.sentence || span.innerText.trim(),
          type: firedSignals.length ? firedSignals.join(", ") : "uncertain content",
        };
      })
      .filter(s => s.text);

    const currentCount = flaggedSentences.length;
    const resetLabel = currentCount > 1 ? `Refine prompt · address all ${currentCount} flags`
                     : currentCount === 1 ? `Refine prompt · address 1 flag`
                     : "Refine prompt";

    chrome.runtime.sendMessage(
      { type: "REWRITE_ALL", prompt, flaggedSentences },
      (response) => {
        btn.disabled = false;
        btn.textContent = resetLabel;
        if (!response?.ok || !response.data?.rewritten) {
          btn.textContent = "Refinement failed — is the API running?";
          setTimeout(() => { btn.textContent = resetLabel; }, 3000);
          return;
        }
        const rewritten = response.data.rewritten;
        promptHistory.push({ text: rewritten, mode: "rewrite" });
        injectIntoClaudeInput(rewritten);
      }
    );
  });

  // Insert bar as a full-width strip after Claude's native action bar row,
  // falling back to appending inside the response container.
  const actionBar = findClaudeActionBar(container);
  if (actionBar) {
    actionBar.insertAdjacentElement("afterend", bar);
  } else {
    container.appendChild(bar);
  }
  _barByContainer.set(container, bar);

  // First-use onboarding
  chrome.storage.local.get(["clOnboarded"], (data) => {
    if (!data.clOnboarded) showOnboarding(flagged[0]);
  });
}

// ─── Update response bar after flag resolution ────────────────────────────────
// Called from the tooltip resolve handler whenever a sentence becomes fully resolved.
function updateResponseBar(container) {
  const bar = _barByContainer.get(container) || container?.querySelector(".cl-response-bar");
  if (!bar || bar.querySelector(".cl-response-bar-clean")) return;

  const remaining = [...container.querySelectorAll(
    "[data-certainty='low'], [data-certainty='medium'], [data-certainty='info']"
  )].length;

  if (remaining === 0) {
    bar.innerHTML = `<span class="cl-response-bar-clean">✓ No flags detected in this response</span>`;
    return;
  }

  const countEl = bar.querySelector(".cl-flag-count");
  const labelEl = bar.querySelector(".cl-response-bar-label");
  const refineBtn = bar.querySelector(".cl-refine-all-btn");

  if (countEl) countEl.textContent = remaining;
  if (labelEl) {
    // Re-render the "flag/flags" plural inline
    labelEl.innerHTML = `✦ <span class="cl-flag-count">${remaining}</span> flag${remaining !== 1 ? "s" : ""} detected`;
  }
  if (refineBtn && !refineBtn.disabled) {
    refineBtn.textContent = remaining > 1
      ? `Refine prompt · address all ${remaining} flags`
      : `Refine prompt · address 1 flag`;
  }
}

// ─── DOM observation ─────────────────────────────────────────────────────────

function scanForContainers(root) {
  root.querySelectorAll("[data-is-streaming='false']").forEach(processResponseContainer);
}

const observer = new MutationObserver((mutations) => {
  for (const mutation of mutations) {
    if (
      mutation.type === "attributes" &&
      mutation.attributeName === "data-is-streaming" &&
      mutation.target.getAttribute("data-is-streaming") === "false"
    ) {
      processResponseContainer(mutation.target);
      continue;
    }
    for (const node of mutation.addedNodes) {
      if (node.nodeType !== Node.ELEMENT_NODE) continue;
      if (node.hasAttribute("data-is-streaming") && node.getAttribute("data-is-streaming") === "false") {
        processResponseContainer(node);
      } else {
        scanForContainers(node);
      }
    }
  }
});

observer.observe(document.body, {
  childList: true, subtree: true,
  attributes: true, attributeFilter: ["data-is-streaming"],
});

console.log("[InCite] content.js loaded");
scanForContainers(document.body);
