const SIGNAL_API  = "https://incite-production.up.railway.app";
const API_SECRET  = "65d30de6e8b59d6bf832da4f7d59317e54836c8189a53bbf7af83eac10bb5b0c";

chrome.runtime.onInstalled.addListener(() => {
  console.log("[InCite] Extension installed.");
});

// Proxy fetch requests from content scripts (which are blocked by mixed-content
// when calling http://localhost from https://claude.ai)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "ANALYZE") {
    fetch(`${SIGNAL_API}/analyze`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-api-key": API_SECRET },
      body: JSON.stringify({ text: message.text, contentType: message.contentType ?? "natural" }),
    })
      .then((r) => r.json())
      .then((data) => sendResponse({ ok: true, data }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true; // keep channel open for async response
  }

  if (message.type === "HEALTH") {
    fetch(`${SIGNAL_API}/health`)
      .then((r) => r.json())
      .then((data) => sendResponse({ ok: true, data }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === "REWRITE") {
    fetch(`${SIGNAL_API}/rewrite`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-api-key": API_SECRET },
      body: JSON.stringify({
        prompt: message.prompt,
        flaggedSentence: message.flaggedSentence,
        mode: message.mode,
      }),
    })
      .then((r) => r.json())
      .then((data) => sendResponse({ ok: true, data }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === "VERIFY") {
    fetch(`${SIGNAL_API}/verify`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-api-key": API_SECRET },
      body: JSON.stringify({ sentence: message.sentence, signals: message.signals }),
    })
      .then((r) => r.json())
      .then((data) => sendResponse({ ok: true, data }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === "REWRITE_ALL") {
    fetch(`${SIGNAL_API}/rewrite-all`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-api-key": API_SECRET },
      body: JSON.stringify({
        prompt: message.prompt,
        flaggedSentences: message.flaggedSentences,
      }),
    })
      .then((r) => r.json())
      .then((data) => sendResponse({ ok: true, data }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === "PERPLEXITY_VERIFY") {
    fetch(`${SIGNAL_API}/perplexity-verify`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-api-key": API_SECRET },
      body: JSON.stringify({ sentence: message.sentence }),
    })
      .then((r) => r.json())
      .then((data) => sendResponse({ ok: true, data }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === "ANALYSIS_COMPLETE") {
    chrome.action.setBadgeText({
      text: message.flaggedCount ? String(message.flaggedCount) : "",
      tabId: sender.tab.id,
    });
    chrome.action.setBadgeBackgroundColor({ color: "#d96060" });
    sendResponse({ ok: true });
  }

  return true;
});
