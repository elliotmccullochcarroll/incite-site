async function checkApiHealth() {
  const dot = document.getElementById("statusDot");
  const text = document.getElementById("statusText");

  chrome.runtime.sendMessage({ type: "HEALTH" }, (response) => {
    if (chrome.runtime.lastError || !response?.ok) {
      dot.classList.add("offline");
      text.textContent = "Signal API offline (start server)";
    } else {
      dot.classList.remove("offline");
      text.textContent = "Signal API connected";
    }
  });
}

checkApiHealth();
